package android.support.v4.media.session;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.List;

public final class PlaybackStateCompat implements Parcelable {
  public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new a();
  
  public final int f;
  
  public final long g;
  
  public final long h;
  
  public final float i;
  
  public final long j;
  
  public final int k;
  
  public final CharSequence l;
  
  public final long m;
  
  public List<CustomAction> n;
  
  public final long o;
  
  public final Bundle p;
  
  public PlaybackStateCompat(Parcel paramParcel) {
    this.f = paramParcel.readInt();
    this.g = paramParcel.readLong();
    this.i = paramParcel.readFloat();
    this.m = paramParcel.readLong();
    this.h = paramParcel.readLong();
    this.j = paramParcel.readLong();
    this.l = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.n = paramParcel.createTypedArrayList(CustomAction.CREATOR);
    this.o = paramParcel.readLong();
    this.p = paramParcel.readBundle(MediaSessionCompat.class.getClassLoader());
    this.k = paramParcel.readInt();
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("PlaybackState {");
    stringBuilder.append("state=");
    stringBuilder.append(this.f);
    stringBuilder.append(", position=");
    stringBuilder.append(this.g);
    stringBuilder.append(", buffered position=");
    stringBuilder.append(this.h);
    stringBuilder.append(", speed=");
    stringBuilder.append(this.i);
    stringBuilder.append(", updated=");
    stringBuilder.append(this.m);
    stringBuilder.append(", actions=");
    stringBuilder.append(this.j);
    stringBuilder.append(", error code=");
    stringBuilder.append(this.k);
    stringBuilder.append(", error message=");
    stringBuilder.append(this.l);
    stringBuilder.append(", custom actions=");
    stringBuilder.append(this.n);
    stringBuilder.append(", active item id=");
    stringBuilder.append(this.o);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.f);
    paramParcel.writeLong(this.g);
    paramParcel.writeFloat(this.i);
    paramParcel.writeLong(this.m);
    paramParcel.writeLong(this.h);
    paramParcel.writeLong(this.j);
    TextUtils.writeToParcel(this.l, paramParcel, paramInt);
    paramParcel.writeTypedList(this.n);
    paramParcel.writeLong(this.o);
    paramParcel.writeBundle(this.p);
    paramParcel.writeInt(this.k);
  }
  
  public static final class CustomAction implements Parcelable {
    public static final Parcelable.Creator<CustomAction> CREATOR = new a();
    
    public final String f;
    
    public final CharSequence g;
    
    public final int h;
    
    public final Bundle i;
    
    public CustomAction(Parcel param1Parcel) {
      this.f = param1Parcel.readString();
      this.g = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(param1Parcel);
      this.h = param1Parcel.readInt();
      this.i = param1Parcel.readBundle(MediaSessionCompat.class.getClassLoader());
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = android.support.v4.media.a.a("Action:mName='");
      stringBuilder.append(this.g);
      stringBuilder.append(", mIcon=");
      stringBuilder.append(this.h);
      stringBuilder.append(", mExtras=");
      stringBuilder.append(this.i);
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeString(this.f);
      TextUtils.writeToParcel(this.g, param1Parcel, param1Int);
      param1Parcel.writeInt(this.h);
      param1Parcel.writeBundle(this.i);
    }
    
    public static final class a implements Parcelable.Creator<CustomAction> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new PlaybackStateCompat.CustomAction(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new PlaybackStateCompat.CustomAction[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator<CustomAction> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new PlaybackStateCompat.CustomAction(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new PlaybackStateCompat.CustomAction[param1Int];
    }
  }
  
  public static final class a implements Parcelable.Creator<PlaybackStateCompat> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new PlaybackStateCompat(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new PlaybackStateCompat[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\android\support\v4\media\session\PlaybackStateCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */