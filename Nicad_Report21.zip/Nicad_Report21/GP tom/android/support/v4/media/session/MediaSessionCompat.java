package android.support.v4.media.session;

import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.ResultReceiver;
import android.support.v4.media.MediaDescriptionCompat;

public class MediaSessionCompat {
  public static void a(Bundle paramBundle) {
    if (paramBundle != null)
      paramBundle.setClassLoader(MediaSessionCompat.class.getClassLoader()); 
  }
  
  public static final class QueueItem implements Parcelable {
    public static final Parcelable.Creator<QueueItem> CREATOR = new a();
    
    public final MediaDescriptionCompat f;
    
    public final long g;
    
    public QueueItem(Parcel param1Parcel) {
      this.f = (MediaDescriptionCompat)MediaDescriptionCompat.CREATOR.createFromParcel(param1Parcel);
      this.g = param1Parcel.readLong();
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = android.support.v4.media.a.a("MediaSession.QueueItem {Description=");
      stringBuilder.append(this.f);
      stringBuilder.append(", Id=");
      stringBuilder.append(this.g);
      stringBuilder.append(" }");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      this.f.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeLong(this.g);
    }
    
    public static final class a implements Parcelable.Creator<QueueItem> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new MediaSessionCompat.QueueItem(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new MediaSessionCompat.QueueItem[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator<QueueItem> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new MediaSessionCompat.QueueItem(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new MediaSessionCompat.QueueItem[param1Int];
    }
  }
  
  public static final class ResultReceiverWrapper implements Parcelable {
    public static final Parcelable.Creator<ResultReceiverWrapper> CREATOR = new a();
    
    public ResultReceiver f;
    
    public ResultReceiverWrapper(Parcel param1Parcel) {
      this.f = (ResultReceiver)ResultReceiver.CREATOR.createFromParcel(param1Parcel);
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      this.f.writeToParcel(param1Parcel, param1Int);
    }
    
    public static final class a implements Parcelable.Creator<ResultReceiverWrapper> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new MediaSessionCompat.ResultReceiverWrapper(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new MediaSessionCompat.ResultReceiverWrapper[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator<ResultReceiverWrapper> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new MediaSessionCompat.ResultReceiverWrapper(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new MediaSessionCompat.ResultReceiverWrapper[param1Int];
    }
  }
  
  public static final class Token implements Parcelable {
    public static final Parcelable.Creator<Token> CREATOR = new a();
    
    public final Object f;
    
    public a g;
    
    public Token(Object param1Object) {
      this.f = param1Object;
      this.g = null;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof Token))
        return false; 
      Token token = (Token)param1Object;
      param1Object = this.f;
      if (param1Object == null)
        return (token.f == null); 
      Object object = token.f;
      return (object == null) ? false : param1Object.equals(object);
    }
    
    public int hashCode() {
      Object object = this.f;
      return (object == null) ? 0 : object.hashCode();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      if (Build.VERSION.SDK_INT >= 21) {
        param1Parcel.writeParcelable((Parcelable)this.f, param1Int);
        return;
      } 
      param1Parcel.writeStrongBinder((IBinder)this.f);
    }
    
    public static final class a implements Parcelable.Creator<Token> {
      public Object createFromParcel(Parcel param2Parcel) {
        Parcelable parcelable;
        IBinder iBinder;
        if (Build.VERSION.SDK_INT >= 21) {
          parcelable = param2Parcel.readParcelable(null);
        } else {
          iBinder = parcelable.readStrongBinder();
        } 
        return new MediaSessionCompat.Token(iBinder);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new MediaSessionCompat.Token[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator<Token> {
    public Object createFromParcel(Parcel param1Parcel) {
      Parcelable parcelable;
      IBinder iBinder;
      if (Build.VERSION.SDK_INT >= 21) {
        parcelable = param1Parcel.readParcelable(null);
      } else {
        iBinder = parcelable.readStrongBinder();
      } 
      return new MediaSessionCompat.Token(iBinder);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new MediaSessionCompat.Token[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\android\support\v4\media\session\MediaSessionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */