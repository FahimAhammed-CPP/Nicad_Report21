package android.support.v4.media;

import android.graphics.Bitmap;
import android.media.MediaDescription;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.session.MediaSessionCompat;
import android.text.TextUtils;

public final class MediaDescriptionCompat implements Parcelable {
  public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new a();
  
  public final String f;
  
  public final CharSequence g;
  
  public final CharSequence h;
  
  public final CharSequence i;
  
  public final Bitmap j;
  
  public final Uri k;
  
  public final Bundle l;
  
  public final Uri m;
  
  public Object n;
  
  public MediaDescriptionCompat(Parcel paramParcel) {
    this.f = paramParcel.readString();
    this.g = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.h = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.i = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    ClassLoader classLoader = MediaDescriptionCompat.class.getClassLoader();
    this.j = (Bitmap)paramParcel.readParcelable(classLoader);
    this.k = (Uri)paramParcel.readParcelable(classLoader);
    this.l = paramParcel.readBundle(classLoader);
    this.m = (Uri)paramParcel.readParcelable(classLoader);
  }
  
  public MediaDescriptionCompat(String paramString, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, Bitmap paramBitmap, Uri paramUri1, Bundle paramBundle, Uri paramUri2) {
    this.f = paramString;
    this.g = paramCharSequence1;
    this.h = paramCharSequence2;
    this.i = paramCharSequence3;
    this.j = paramBitmap;
    this.k = paramUri1;
    this.l = paramBundle;
    this.m = paramUri2;
  }
  
  public static MediaDescriptionCompat a(Object paramObject) {
    MediaDescriptionCompat mediaDescriptionCompat;
    Bundle bundle2 = null;
    Bundle bundle3 = null;
    Bundle bundle1 = bundle2;
    if (paramObject != null) {
      int i = Build.VERSION.SDK_INT;
      bundle1 = bundle2;
      if (i >= 21) {
        Uri uri1;
        MediaDescription mediaDescription = (MediaDescription)paramObject;
        String str = mediaDescription.getMediaId();
        CharSequence charSequence1 = mediaDescription.getTitle();
        CharSequence charSequence2 = mediaDescription.getSubtitle();
        CharSequence charSequence3 = mediaDescription.getDescription();
        Bitmap bitmap = mediaDescription.getIconBitmap();
        Uri uri2 = mediaDescription.getIconUri();
        bundle2 = mediaDescription.getExtras();
        if (bundle2 != null) {
          MediaSessionCompat.a(bundle2);
          uri1 = (Uri)bundle2.getParcelable("android.support.v4.media.description.MEDIA_URI");
        } else {
          bundle1 = null;
        } 
        if (bundle1 != null)
          if (bundle2.containsKey("android.support.v4.media.description.NULL_BUNDLE_FLAG") && bundle2.size() == 2) {
            bundle2 = null;
          } else {
            bundle2.remove("android.support.v4.media.description.MEDIA_URI");
            bundle2.remove("android.support.v4.media.description.NULL_BUNDLE_FLAG");
          }  
        if (bundle1 == null) {
          bundle1 = bundle3;
          if (i >= 23)
            uri1 = mediaDescription.getMediaUri(); 
        } 
        mediaDescriptionCompat = new MediaDescriptionCompat(str, charSequence1, charSequence2, charSequence3, bitmap, uri2, bundle2, uri1);
        mediaDescriptionCompat.n = paramObject;
      } 
    } 
    return mediaDescriptionCompat;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.g);
    stringBuilder.append(", ");
    stringBuilder.append(this.h);
    stringBuilder.append(", ");
    stringBuilder.append(this.i);
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = Build.VERSION.SDK_INT;
    if (i < 21) {
      paramParcel.writeString(this.f);
      TextUtils.writeToParcel(this.g, paramParcel, paramInt);
      TextUtils.writeToParcel(this.h, paramParcel, paramInt);
      TextUtils.writeToParcel(this.i, paramParcel, paramInt);
      paramParcel.writeParcelable((Parcelable)this.j, paramInt);
      paramParcel.writeParcelable((Parcelable)this.k, paramInt);
      paramParcel.writeBundle(this.l);
      paramParcel.writeParcelable((Parcelable)this.m, paramInt);
      return;
    } 
    Object object2 = this.n;
    Object object1 = object2;
    if (object2 == null)
      if (i < 21) {
        object1 = object2;
      } else {
        MediaDescription.Builder builder = new MediaDescription.Builder();
        builder.setMediaId(this.f);
        builder.setTitle(this.g);
        builder.setSubtitle(this.h);
        builder.setDescription(this.i);
        builder.setIconBitmap(this.j);
        builder.setIconUri(this.k);
        object2 = this.l;
        object1 = object2;
        if (i < 23) {
          object1 = object2;
          if (this.m != null) {
            object1 = object2;
            if (object2 == null) {
              object1 = new Bundle();
              object1.putBoolean("android.support.v4.media.description.NULL_BUNDLE_FLAG", true);
            } 
            object1.putParcelable("android.support.v4.media.description.MEDIA_URI", (Parcelable)this.m);
          } 
        } 
        builder.setExtras((Bundle)object1);
        if (i >= 23)
          builder.setMediaUri(this.m); 
        object1 = builder.build();
        this.n = object1;
      }  
    ((MediaDescription)object1).writeToParcel(paramParcel, paramInt);
  }
  
  public static final class a implements Parcelable.Creator<MediaDescriptionCompat> {
    public Object createFromParcel(Parcel param1Parcel) {
      return (Build.VERSION.SDK_INT < 21) ? new MediaDescriptionCompat(param1Parcel) : MediaDescriptionCompat.a(MediaDescription.CREATOR.createFromParcel(param1Parcel));
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new MediaDescriptionCompat[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Gardenscapes-dex2jar.jar!\android\support\v4\media\MediaDescriptionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */