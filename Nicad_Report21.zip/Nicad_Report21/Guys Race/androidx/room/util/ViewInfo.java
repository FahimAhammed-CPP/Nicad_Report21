package androidx.room.util;

import android.database.Cursor;
import androidx.sqlite.db.SupportSQLiteDatabase;

public class ViewInfo {
  public final String name;
  
  public final String sql;
  
  public ViewInfo(String paramString1, String paramString2) {
    this.name = paramString1;
    this.sql = paramString2;
  }
  
  public static ViewInfo read(SupportSQLiteDatabase paramSupportSQLiteDatabase, String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("SELECT name, sql FROM sqlite_master WHERE type = 'view' AND name = '");
    stringBuilder.append(paramString);
    stringBuilder.append("'");
    Cursor cursor = paramSupportSQLiteDatabase.query(stringBuilder.toString());
    try {
      if (cursor.moveToFirst()) {
        viewInfo = new ViewInfo(cursor.getString(0), cursor.getString(1));
        return viewInfo;
      } 
      ViewInfo viewInfo = new ViewInfo((String)viewInfo, null);
      return viewInfo;
    } finally {
      cursor.close();
    } 
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (getClass() != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      String str = this.name;
      if ((str != null) ? str.equals(((ViewInfo)paramObject).name) : (((ViewInfo)paramObject).name == null)) {
        str = this.sql;
        if (str != null) {
          if (str.equals(((ViewInfo)paramObject).sql))
            return true; 
        } else if (((ViewInfo)paramObject).sql == null) {
          return true;
        } 
      } 
      return false;
    } 
    return false;
  }
  
  public int hashCode() {
    byte b;
    String str = this.name;
    int i = 0;
    if (str != null) {
      b = str.hashCode();
    } else {
      b = 0;
    } 
    str = this.sql;
    if (str != null)
      i = str.hashCode(); 
    return b * 31 + i;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ViewInfo{name='");
    stringBuilder.append(this.name);
    stringBuilder.append('\'');
    stringBuilder.append(", sql='");
    stringBuilder.append(this.sql);
    stringBuilder.append('\'');
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Guys Race-dex2jar.jar!\androidx\roo\\util\ViewInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */