package androidx.room.util;

import android.os.Build;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;

public class FileUtil {
  public static void copy(ReadableByteChannel paramReadableByteChannel, FileChannel paramFileChannel) throws IOException {
    try {
      if (Build.VERSION.SDK_INT > 23) {
        paramFileChannel.transferFrom(paramReadableByteChannel, 0L, Long.MAX_VALUE);
      } else {
        InputStream inputStream = Channels.newInputStream(paramReadableByteChannel);
        OutputStream outputStream = Channels.newOutputStream(paramFileChannel);
        byte[] arrayOfByte = new byte[4096];
        while (true) {
          int i = inputStream.read(arrayOfByte);
          if (i > 0) {
            outputStream.write(arrayOfByte, 0, i);
            continue;
          } 
          break;
        } 
      } 
      paramFileChannel.force(false);
      return;
    } finally {
      paramReadableByteChannel.close();
      paramFileChannel.close();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Guys Race-dex2jar.jar!\androidx\roo\\util\FileUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */