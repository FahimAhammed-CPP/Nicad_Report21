package androidx.room.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class CopyLock {
  private static final Map<String, Lock> sThreadLocks = new HashMap<String, Lock>();
  
  private final File mCopyLockFile;
  
  private final boolean mFileLevelLock;
  
  private FileChannel mLockChannel;
  
  private final Lock mThreadLock;
  
  public CopyLock(String paramString, File paramFile, boolean paramBoolean) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append(".lck");
    File file = new File(paramFile, stringBuilder.toString());
    this.mCopyLockFile = file;
    this.mThreadLock = getThreadLock(file.getAbsolutePath());
    this.mFileLevelLock = paramBoolean;
  }
  
  private static Lock getThreadLock(String paramString) {
    synchronized (sThreadLocks) {
      Lock lock2 = sThreadLocks.get(paramString);
      Lock lock1 = lock2;
      if (lock2 == null) {
        lock1 = new ReentrantLock();
        sThreadLocks.put(paramString, lock1);
      } 
      return lock1;
    } 
  }
  
  public void lock() {
    this.mThreadLock.lock();
    if (this.mFileLevelLock)
      try {
        FileChannel fileChannel = (new FileOutputStream(this.mCopyLockFile)).getChannel();
        this.mLockChannel = fileChannel;
        fileChannel.lock();
        return;
      } catch (IOException iOException) {
        throw new IllegalStateException("Unable to grab copy lock.", iOException);
      }  
  }
  
  public void unlock() {
    FileChannel fileChannel = this.mLockChannel;
    if (fileChannel != null)
      try {
        fileChannel.close();
      } catch (IOException iOException) {} 
    this.mThreadLock.unlock();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Guys Race-dex2jar.jar!\androidx\roo\\util\CopyLock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */