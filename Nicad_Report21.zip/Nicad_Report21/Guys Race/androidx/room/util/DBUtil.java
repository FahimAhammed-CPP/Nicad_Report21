package androidx.room.util;

import android.database.AbstractWindowedCursor;
import android.database.Cursor;
import android.os.Build;
import android.os.CancellationSignal;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteQuery;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;

public class DBUtil {
  public static CancellationSignal createCancellationSignal() {
    return (Build.VERSION.SDK_INT >= 16) ? new CancellationSignal() : null;
  }
  
  public static void dropFtsSyncTriggers(SupportSQLiteDatabase paramSupportSQLiteDatabase) {
    ArrayList<String> arrayList = new ArrayList();
    Cursor cursor = paramSupportSQLiteDatabase.query("SELECT name FROM sqlite_master WHERE type = 'trigger'");
    try {
      while (cursor.moveToNext())
        arrayList.add(cursor.getString(0)); 
      cursor.close();
      return;
    } finally {
      cursor.close();
    } 
  }
  
  @Deprecated
  public static Cursor query(RoomDatabase paramRoomDatabase, SupportSQLiteQuery paramSupportSQLiteQuery, boolean paramBoolean) {
    return query(paramRoomDatabase, paramSupportSQLiteQuery, paramBoolean, null);
  }
  
  public static Cursor query(RoomDatabase paramRoomDatabase, SupportSQLiteQuery paramSupportSQLiteQuery, boolean paramBoolean, CancellationSignal paramCancellationSignal) {
    AbstractWindowedCursor abstractWindowedCursor;
    Cursor cursor = paramRoomDatabase.query(paramSupportSQLiteQuery, paramCancellationSignal);
    null = cursor;
    if (paramBoolean) {
      null = cursor;
      if (cursor instanceof AbstractWindowedCursor) {
        int i;
        abstractWindowedCursor = (AbstractWindowedCursor)cursor;
        int j = abstractWindowedCursor.getCount();
        if (abstractWindowedCursor.hasWindow()) {
          i = abstractWindowedCursor.getWindow().getNumRows();
        } else {
          i = j;
        } 
        if (Build.VERSION.SDK_INT >= 23) {
          null = cursor;
          return (i < j) ? CursorUtil.copyAndClose((Cursor)abstractWindowedCursor) : null;
        } 
      } else {
        return null;
      } 
    } else {
      return null;
    } 
    return CursorUtil.copyAndClose((Cursor)abstractWindowedCursor);
  }
  
  public static int readVersion(File paramFile) throws IOException {
    FileChannel fileChannel2 = null;
    FileChannel fileChannel1 = fileChannel2;
    try {
      ByteBuffer byteBuffer = ByteBuffer.allocate(4);
      fileChannel1 = fileChannel2;
      FileChannel fileChannel = (new FileInputStream(paramFile)).getChannel();
      fileChannel1 = fileChannel;
      fileChannel.tryLock(60L, 4L, true);
      fileChannel1 = fileChannel;
      fileChannel.position(60L);
      fileChannel1 = fileChannel;
      if (fileChannel.read(byteBuffer) == 4) {
        fileChannel1 = fileChannel;
        byteBuffer.rewind();
        fileChannel1 = fileChannel;
        return byteBuffer.getInt();
      } 
      fileChannel1 = fileChannel;
      throw new IOException("Bad database header, unable to read 4 bytes at offset 60");
    } finally {
      if (fileChannel1 != null)
        fileChannel1.close(); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Guys Race-dex2jar.jar!\androidx\roo\\util\DBUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */