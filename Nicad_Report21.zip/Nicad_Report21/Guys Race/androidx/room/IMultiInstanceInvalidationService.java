package androidx.room;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface IMultiInstanceInvalidationService extends IInterface {
  void broadcastInvalidation(int paramInt, String[] paramArrayOfString) throws RemoteException;
  
  int registerCallback(IMultiInstanceInvalidationCallback paramIMultiInstanceInvalidationCallback, String paramString) throws RemoteException;
  
  void unregisterCallback(IMultiInstanceInvalidationCallback paramIMultiInstanceInvalidationCallback, int paramInt) throws RemoteException;
  
  public static abstract class Stub extends Binder implements IMultiInstanceInvalidationService {
    private static final String DESCRIPTOR = "androidx.room.IMultiInstanceInvalidationService";
    
    static final int TRANSACTION_broadcastInvalidation = 3;
    
    static final int TRANSACTION_registerCallback = 1;
    
    static final int TRANSACTION_unregisterCallback = 2;
    
    public Stub() {
      attachInterface(this, "androidx.room.IMultiInstanceInvalidationService");
    }
    
    public static IMultiInstanceInvalidationService asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("androidx.room.IMultiInstanceInvalidationService");
      return (iInterface != null && iInterface instanceof IMultiInstanceInvalidationService) ? (IMultiInstanceInvalidationService)iInterface : new Proxy(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      if (param1Int1 != 1) {
        if (param1Int1 != 2) {
          if (param1Int1 != 3) {
            if (param1Int1 != 1598968902)
              return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
            param1Parcel2.writeString("androidx.room.IMultiInstanceInvalidationService");
            return true;
          } 
          param1Parcel1.enforceInterface("androidx.room.IMultiInstanceInvalidationService");
          broadcastInvalidation(param1Parcel1.readInt(), param1Parcel1.createStringArray());
          return true;
        } 
        param1Parcel1.enforceInterface("androidx.room.IMultiInstanceInvalidationService");
        unregisterCallback(IMultiInstanceInvalidationCallback.Stub.asInterface(param1Parcel1.readStrongBinder()), param1Parcel1.readInt());
        param1Parcel2.writeNoException();
        return true;
      } 
      param1Parcel1.enforceInterface("androidx.room.IMultiInstanceInvalidationService");
      param1Int1 = registerCallback(IMultiInstanceInvalidationCallback.Stub.asInterface(param1Parcel1.readStrongBinder()), param1Parcel1.readString());
      param1Parcel2.writeNoException();
      param1Parcel2.writeInt(param1Int1);
      return true;
    }
    
    private static class Proxy implements IMultiInstanceInvalidationService {
      private IBinder mRemote;
      
      Proxy(IBinder param2IBinder) {
        this.mRemote = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.mRemote;
      }
      
      public void broadcastInvalidation(int param2Int, String[] param2ArrayOfString) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationService");
          parcel.writeInt(param2Int);
          parcel.writeStringArray(param2ArrayOfString);
          this.mRemote.transact(3, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public String getInterfaceDescriptor() {
        return "androidx.room.IMultiInstanceInvalidationService";
      }
      
      public int registerCallback(IMultiInstanceInvalidationCallback param2IMultiInstanceInvalidationCallback, String param2String) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
        
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
        param2IMultiInstanceInvalidationCallback = null;
        parcel1.writeStrongBinder((IBinder)param2IMultiInstanceInvalidationCallback);
        parcel1.writeString(param2String);
        this.mRemote.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        int i = parcel2.readInt();
        parcel2.recycle();
        parcel1.recycle();
        return i;
      }
      
      public void unregisterCallback(IMultiInstanceInvalidationCallback param2IMultiInstanceInvalidationCallback, int param2Int) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationService");
          if (param2IMultiInstanceInvalidationCallback != null) {
            IBinder iBinder = param2IMultiInstanceInvalidationCallback.asBinder();
          } else {
            param2IMultiInstanceInvalidationCallback = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2IMultiInstanceInvalidationCallback);
          parcel1.writeInt(param2Int);
          this.mRemote.transact(2, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class Proxy implements IMultiInstanceInvalidationService {
    private IBinder mRemote;
    
    Proxy(IBinder param1IBinder) {
      this.mRemote = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.mRemote;
    }
    
    public void broadcastInvalidation(int param1Int, String[] param1ArrayOfString) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationService");
        parcel.writeInt(param1Int);
        parcel.writeStringArray(param1ArrayOfString);
        this.mRemote.transact(3, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public String getInterfaceDescriptor() {
      return "androidx.room.IMultiInstanceInvalidationService";
    }
    
    public int registerCallback(IMultiInstanceInvalidationCallback param1IMultiInstanceInvalidationCallback, String param1String) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
      
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
      param1IMultiInstanceInvalidationCallback = null;
      parcel1.writeStrongBinder((IBinder)param1IMultiInstanceInvalidationCallback);
      parcel1.writeString(param1String);
      this.mRemote.transact(1, parcel1, parcel2, 0);
      parcel2.readException();
      int i = parcel2.readInt();
      parcel2.recycle();
      parcel1.recycle();
      return i;
    }
    
    public void unregisterCallback(IMultiInstanceInvalidationCallback param1IMultiInstanceInvalidationCallback, int param1Int) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationService");
        if (param1IMultiInstanceInvalidationCallback != null) {
          IBinder iBinder = param1IMultiInstanceInvalidationCallback.asBinder();
        } else {
          param1IMultiInstanceInvalidationCallback = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1IMultiInstanceInvalidationCallback);
        parcel1.writeInt(param1Int);
        this.mRemote.transact(2, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Guys Race-dex2jar.jar!\androidx\room\IMultiInstanceInvalidationService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */