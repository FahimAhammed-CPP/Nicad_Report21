package androidx.core.content;

import android.content.LocusId;
import android.os.Build;
import androidx.core.util.Preconditions;

public final class LocusIdCompat {
  private final String mId;
  
  private final LocusId mWrapped;
  
  public LocusIdCompat(String paramString) {
    this.mId = (String)Preconditions.checkStringNotEmpty(paramString, "id cannot be empty");
    if (Build.VERSION.SDK_INT >= 29) {
      this.mWrapped = Api29Impl.create(paramString);
      return;
    } 
    this.mWrapped = null;
  }
  
  private String getSanitizedId() {
    int i = this.mId.length();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(i);
    stringBuilder.append("_chars");
    return stringBuilder.toString();
  }
  
  public static LocusIdCompat toLocusIdCompat(LocusId paramLocusId) {
    Preconditions.checkNotNull(paramLocusId, "locusId cannot be null");
    return new LocusIdCompat((String)Preconditions.checkStringNotEmpty(Api29Impl.getId(paramLocusId), "id cannot be empty"));
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject == null)
      return false; 
    if (getClass() != paramObject.getClass())
      return false; 
    paramObject = paramObject;
    String str = this.mId;
    return (str == null) ? ((((LocusIdCompat)paramObject).mId == null)) : str.equals(((LocusIdCompat)paramObject).mId);
  }
  
  public String getId() {
    return this.mId;
  }
  
  public int hashCode() {
    int i;
    String str = this.mId;
    if (str == null) {
      i = 0;
    } else {
      i = str.hashCode();
    } 
    return 31 + i;
  }
  
  public LocusId toLocusId() {
    return this.mWrapped;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("LocusIdCompat[");
    stringBuilder.append(getSanitizedId());
    stringBuilder.append("]");
    return stringBuilder.toString();
  }
  
  private static class Api29Impl {
    static LocusId create(String param1String) {
      return new LocusId(param1String);
    }
    
    static String getId(LocusId param1LocusId) {
      return param1LocusId.getId();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Guys Race-dex2jar.jar!\androidx\core\content\LocusIdCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */