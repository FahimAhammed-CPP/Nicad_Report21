package androidx.core.os;

import android.os.Build;

public class BuildCompat {
  @Deprecated
  public static boolean isAtLeastN() {
    return (Build.VERSION.SDK_INT >= 24);
  }
  
  @Deprecated
  public static boolean isAtLeastNMR1() {
    return (Build.VERSION.SDK_INT >= 25);
  }
  
  @Deprecated
  public static boolean isAtLeastO() {
    return (Build.VERSION.SDK_INT >= 26);
  }
  
  @Deprecated
  public static boolean isAtLeastOMR1() {
    return (Build.VERSION.SDK_INT >= 27);
  }
  
  @Deprecated
  public static boolean isAtLeastP() {
    return (Build.VERSION.SDK_INT >= 28);
  }
  
  protected static boolean isAtLeastPreReleaseCodename(String paramString1, String paramString2) {
    boolean bool1 = "REL".equals(paramString2);
    boolean bool = false;
    if (bool1)
      return false; 
    if (paramString2.compareTo(paramString1) >= 0)
      bool = true; 
    return bool;
  }
  
  @Deprecated
  public static boolean isAtLeastQ() {
    return (Build.VERSION.SDK_INT >= 29);
  }
  
  @Deprecated
  public static boolean isAtLeastR() {
    return (Build.VERSION.SDK_INT >= 30);
  }
  
  public static boolean isAtLeastS() {
    return (Build.VERSION.SDK_INT >= 31 || isAtLeastPreReleaseCodename("S", Build.VERSION.CODENAME));
  }
  
  public static boolean isAtLeastT() {
    return isAtLeastPreReleaseCodename("T", Build.VERSION.CODENAME);
  }
  
  public static @interface PrereleaseSdkCheck {}
}


/* Location:              C:\soft\dex2jar-2.0\Guys Race-dex2jar.jar!\androidx\core\os\BuildCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */