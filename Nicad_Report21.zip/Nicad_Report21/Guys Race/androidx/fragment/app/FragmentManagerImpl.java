package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.Transformation;
import androidx.collection.ArraySet;
import androidx.core.util.DebugUtils;
import androidx.core.util.LogWriter;
import androidx.core.view.ViewCompat;
import androidx.lifecycle.ViewModelStore;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

final class FragmentManagerImpl extends FragmentManager implements LayoutInflater.Factory2 {
  static final Interpolator ACCELERATE_CUBIC;
  
  static final Interpolator ACCELERATE_QUINT;
  
  static final int ANIM_DUR = 220;
  
  public static final int ANIM_STYLE_CLOSE_ENTER = 3;
  
  public static final int ANIM_STYLE_CLOSE_EXIT = 4;
  
  public static final int ANIM_STYLE_FADE_ENTER = 5;
  
  public static final int ANIM_STYLE_FADE_EXIT = 6;
  
  public static final int ANIM_STYLE_OPEN_ENTER = 1;
  
  public static final int ANIM_STYLE_OPEN_EXIT = 2;
  
  static boolean DEBUG = false;
  
  static final Interpolator DECELERATE_CUBIC;
  
  static final Interpolator DECELERATE_QUINT = (Interpolator)new DecelerateInterpolator(2.5F);
  
  static final String TAG = "FragmentManager";
  
  static final String TARGET_REQUEST_CODE_STATE_TAG = "android:target_req_state";
  
  static final String TARGET_STATE_TAG = "android:target_state";
  
  static final String USER_VISIBLE_HINT_TAG = "android:user_visible_hint";
  
  static final String VIEW_STATE_TAG = "android:view_state";
  
  static Field sAnimationListenerField;
  
  SparseArray<Fragment> mActive;
  
  final ArrayList<Fragment> mAdded = new ArrayList<Fragment>();
  
  ArrayList<Integer> mAvailBackStackIndices;
  
  ArrayList<BackStackRecord> mBackStack;
  
  ArrayList<FragmentManager.OnBackStackChangedListener> mBackStackChangeListeners;
  
  ArrayList<BackStackRecord> mBackStackIndices;
  
  FragmentContainer mContainer;
  
  ArrayList<Fragment> mCreatedMenus;
  
  int mCurState = 0;
  
  boolean mDestroyed;
  
  Runnable mExecCommit = new Runnable() {
      public void run() {
        FragmentManagerImpl.this.execPendingActions();
      }
    };
  
  boolean mExecutingActions;
  
  boolean mHavePendingDeferredStart;
  
  FragmentHostCallback mHost;
  
  private final CopyOnWriteArrayList<FragmentLifecycleCallbacksHolder> mLifecycleCallbacks = new CopyOnWriteArrayList<FragmentLifecycleCallbacksHolder>();
  
  boolean mNeedMenuInvalidate;
  
  int mNextFragmentIndex = 0;
  
  String mNoTransactionsBecause;
  
  Fragment mParent;
  
  ArrayList<OpGenerator> mPendingActions;
  
  ArrayList<StartEnterTransitionListener> mPostponedTransactions;
  
  Fragment mPrimaryNav;
  
  FragmentManagerNonConfig mSavedNonConfig;
  
  SparseArray<Parcelable> mStateArray = null;
  
  Bundle mStateBundle = null;
  
  boolean mStateSaved;
  
  boolean mStopped;
  
  ArrayList<Fragment> mTmpAddedFragments;
  
  ArrayList<Boolean> mTmpIsPop;
  
  ArrayList<BackStackRecord> mTmpRecords;
  
  static {
    DECELERATE_CUBIC = (Interpolator)new DecelerateInterpolator(1.5F);
    ACCELERATE_QUINT = (Interpolator)new AccelerateInterpolator(2.5F);
    ACCELERATE_CUBIC = (Interpolator)new AccelerateInterpolator(1.5F);
  }
  
  private void addAddedFragments(ArraySet<Fragment> paramArraySet) {
    int i = this.mCurState;
    if (i < 1)
      return; 
    int j = Math.min(i, 3);
    int k = this.mAdded.size();
    for (i = 0; i < k; i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment.mState < j) {
        moveToState(fragment, j, fragment.getNextAnim(), fragment.getNextTransition(), false);
        if (fragment.mView != null && !fragment.mHidden && fragment.mIsNewlyAdded)
          paramArraySet.add(fragment); 
      } 
    } 
  }
  
  private void animateRemoveFragment(final Fragment fragment, AnimationOrAnimator paramAnimationOrAnimator, int paramInt) {
    final View viewToAnimate = fragment.mView;
    final ViewGroup container = fragment.mContainer;
    viewGroup.startViewTransition(view);
    fragment.setStateAfterAnimating(paramInt);
    if (paramAnimationOrAnimator.animation != null) {
      EndViewTransitionAnimator endViewTransitionAnimator = new EndViewTransitionAnimator(paramAnimationOrAnimator.animation, viewGroup, view);
      fragment.setAnimatingAway(fragment.mView);
      endViewTransitionAnimator.setAnimationListener(new AnimationListenerWrapper(getAnimationListener((Animation)endViewTransitionAnimator)) {
            public void onAnimationEnd(Animation param1Animation) {
              super.onAnimationEnd(param1Animation);
              container.post(new Runnable() {
                    public void run() {
                      if (fragment.getAnimatingAway() != null) {
                        fragment.setAnimatingAway(null);
                        FragmentManagerImpl.this.moveToState(fragment, fragment.getStateAfterAnimating(), 0, 0, false);
                      } 
                    }
                  });
            }
          });
      setHWLayerAnimListenerIfAlpha(view, paramAnimationOrAnimator);
      fragment.mView.startAnimation((Animation)endViewTransitionAnimator);
      return;
    } 
    Animator animator = paramAnimationOrAnimator.animator;
    fragment.setAnimator(paramAnimationOrAnimator.animator);
    animator.addListener((Animator.AnimatorListener)new AnimatorListenerAdapter() {
          public void onAnimationEnd(Animator param1Animator) {
            container.endViewTransition(viewToAnimate);
            param1Animator = fragment.getAnimator();
            fragment.setAnimator(null);
            if (param1Animator != null && container.indexOfChild(viewToAnimate) < 0) {
              FragmentManagerImpl fragmentManagerImpl = FragmentManagerImpl.this;
              Fragment fragment = fragment;
              fragmentManagerImpl.moveToState(fragment, fragment.getStateAfterAnimating(), 0, 0, false);
            } 
          }
        });
    animator.setTarget(fragment.mView);
    setHWLayerAnimListenerIfAlpha(fragment.mView, paramAnimationOrAnimator);
    animator.start();
  }
  
  private void burpActive() {
    SparseArray<Fragment> sparseArray = this.mActive;
    if (sparseArray != null)
      for (int i = sparseArray.size() - 1; i >= 0; i--) {
        if (this.mActive.valueAt(i) == null) {
          sparseArray = this.mActive;
          sparseArray.delete(sparseArray.keyAt(i));
        } 
      }  
  }
  
  private void checkStateLoss() {
    if (!isStateSaved()) {
      if (this.mNoTransactionsBecause == null)
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Can not perform this action inside of ");
      stringBuilder.append(this.mNoTransactionsBecause);
      throw new IllegalStateException(stringBuilder.toString());
    } 
    throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
  }
  
  private void cleanupExec() {
    this.mExecutingActions = false;
    this.mTmpIsPop.clear();
    this.mTmpRecords.clear();
  }
  
  private void dispatchStateChange(int paramInt) {
    try {
      this.mExecutingActions = true;
      moveToState(paramInt, false);
      this.mExecutingActions = false;
      return;
    } finally {
      this.mExecutingActions = false;
    } 
  }
  
  private void endAnimatingAwayFragments() {
    int i;
    SparseArray<Fragment> sparseArray = this.mActive;
    int j = 0;
    if (sparseArray == null) {
      i = 0;
    } else {
      i = sparseArray.size();
    } 
    while (j < i) {
      Fragment fragment = (Fragment)this.mActive.valueAt(j);
      if (fragment != null)
        if (fragment.getAnimatingAway() != null) {
          int k = fragment.getStateAfterAnimating();
          View view = fragment.getAnimatingAway();
          Animation animation = view.getAnimation();
          if (animation != null) {
            animation.cancel();
            view.clearAnimation();
          } 
          fragment.setAnimatingAway(null);
          moveToState(fragment, k, 0, 0, false);
        } else if (fragment.getAnimator() != null) {
          fragment.getAnimator().end();
        }  
      j++;
    } 
  }
  
  private void ensureExecReady(boolean paramBoolean) {
    if (!this.mExecutingActions) {
      if (this.mHost != null) {
        if (Looper.myLooper() == this.mHost.getHandler().getLooper()) {
          if (!paramBoolean)
            checkStateLoss(); 
          if (this.mTmpRecords == null) {
            this.mTmpRecords = new ArrayList<BackStackRecord>();
            this.mTmpIsPop = new ArrayList<Boolean>();
          } 
          this.mExecutingActions = true;
          try {
            executePostponedTransaction(null, null);
            return;
          } finally {
            this.mExecutingActions = false;
          } 
        } 
        throw new IllegalStateException("Must be called from main thread of fragment host");
      } 
      throw new IllegalStateException("Fragment host has been destroyed");
    } 
    throw new IllegalStateException("FragmentManager is already executing transactions");
  }
  
  private static void executeOps(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    while (paramInt1 < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(paramInt1);
      boolean bool1 = ((Boolean)paramArrayList1.get(paramInt1)).booleanValue();
      boolean bool = true;
      if (bool1) {
        backStackRecord.bumpBackStackNesting(-1);
        if (paramInt1 != paramInt2 - 1)
          bool = false; 
        backStackRecord.executePopOps(bool);
      } else {
        backStackRecord.bumpBackStackNesting(1);
        backStackRecord.executeOps();
      } 
      paramInt1++;
    } 
  }
  
  private void executeOpsTogether(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    int i = paramInt1;
    boolean bool1 = ((BackStackRecord)paramArrayList.get(i)).mReorderingAllowed;
    ArrayList<Fragment> arrayList = this.mTmpAddedFragments;
    if (arrayList == null) {
      this.mTmpAddedFragments = new ArrayList<Fragment>();
    } else {
      arrayList.clear();
    } 
    this.mTmpAddedFragments.addAll(this.mAdded);
    Fragment fragment = getPrimaryNavigationFragment();
    int j = i;
    boolean bool = false;
    while (j < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(j);
      if (!((Boolean)paramArrayList1.get(j)).booleanValue()) {
        fragment = backStackRecord.expandOps(this.mTmpAddedFragments, fragment);
      } else {
        fragment = backStackRecord.trackAddedFragmentsInPop(this.mTmpAddedFragments, fragment);
      } 
      if (bool || backStackRecord.mAddToBackStack) {
        bool = true;
      } else {
        bool = false;
      } 
      j++;
    } 
    this.mTmpAddedFragments.clear();
    if (!bool1)
      FragmentTransition.startTransitions(this, paramArrayList, paramArrayList1, paramInt1, paramInt2, false); 
    executeOps(paramArrayList, paramArrayList1, paramInt1, paramInt2);
    if (bool1) {
      ArraySet<Fragment> arraySet = new ArraySet();
      addAddedFragments(arraySet);
      j = postponePostponableTransactions(paramArrayList, paramArrayList1, paramInt1, paramInt2, arraySet);
      makeRemovedFragmentsInvisible(arraySet);
    } else {
      j = paramInt2;
    } 
    int k = i;
    if (j != i) {
      k = i;
      if (bool1) {
        FragmentTransition.startTransitions(this, paramArrayList, paramArrayList1, paramInt1, j, true);
        moveToState(this.mCurState, true);
        k = i;
      } 
    } 
    while (k < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(k);
      if (((Boolean)paramArrayList1.get(k)).booleanValue() && backStackRecord.mIndex >= 0) {
        freeBackStackIndex(backStackRecord.mIndex);
        backStackRecord.mIndex = -1;
      } 
      backStackRecord.runOnCommitRunnables();
      k++;
    } 
    if (bool)
      reportBackStackChanged(); 
  }
  
  private void executePostponedTransaction(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   4: astore #7
    //   6: aload #7
    //   8: ifnonnull -> 17
    //   11: iconst_0
    //   12: istore #4
    //   14: goto -> 24
    //   17: aload #7
    //   19: invokevirtual size : ()I
    //   22: istore #4
    //   24: iconst_0
    //   25: istore_3
    //   26: iload_3
    //   27: iload #4
    //   29: if_icmpge -> 233
    //   32: aload_0
    //   33: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   36: iload_3
    //   37: invokevirtual get : (I)Ljava/lang/Object;
    //   40: checkcast androidx/fragment/app/FragmentManagerImpl$StartEnterTransitionListener
    //   43: astore #7
    //   45: aload_1
    //   46: ifnull -> 104
    //   49: aload #7
    //   51: getfield mIsBack : Z
    //   54: ifne -> 104
    //   57: aload_1
    //   58: aload #7
    //   60: getfield mRecord : Landroidx/fragment/app/BackStackRecord;
    //   63: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   66: istore #5
    //   68: iload #5
    //   70: iconst_m1
    //   71: if_icmpeq -> 104
    //   74: aload_2
    //   75: iload #5
    //   77: invokevirtual get : (I)Ljava/lang/Object;
    //   80: checkcast java/lang/Boolean
    //   83: invokevirtual booleanValue : ()Z
    //   86: ifeq -> 104
    //   89: aload #7
    //   91: invokevirtual cancelTransaction : ()V
    //   94: iload #4
    //   96: istore #5
    //   98: iload_3
    //   99: istore #6
    //   101: goto -> 221
    //   104: aload #7
    //   106: invokevirtual isReady : ()Z
    //   109: ifne -> 147
    //   112: iload #4
    //   114: istore #5
    //   116: iload_3
    //   117: istore #6
    //   119: aload_1
    //   120: ifnull -> 221
    //   123: iload #4
    //   125: istore #5
    //   127: iload_3
    //   128: istore #6
    //   130: aload #7
    //   132: getfield mRecord : Landroidx/fragment/app/BackStackRecord;
    //   135: aload_1
    //   136: iconst_0
    //   137: aload_1
    //   138: invokevirtual size : ()I
    //   141: invokevirtual interactsWith : (Ljava/util/ArrayList;II)Z
    //   144: ifeq -> 221
    //   147: aload_0
    //   148: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   151: iload_3
    //   152: invokevirtual remove : (I)Ljava/lang/Object;
    //   155: pop
    //   156: iload_3
    //   157: iconst_1
    //   158: isub
    //   159: istore #6
    //   161: iload #4
    //   163: iconst_1
    //   164: isub
    //   165: istore #5
    //   167: aload_1
    //   168: ifnull -> 216
    //   171: aload #7
    //   173: getfield mIsBack : Z
    //   176: ifne -> 216
    //   179: aload_1
    //   180: aload #7
    //   182: getfield mRecord : Landroidx/fragment/app/BackStackRecord;
    //   185: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   188: istore_3
    //   189: iload_3
    //   190: iconst_m1
    //   191: if_icmpeq -> 216
    //   194: aload_2
    //   195: iload_3
    //   196: invokevirtual get : (I)Ljava/lang/Object;
    //   199: checkcast java/lang/Boolean
    //   202: invokevirtual booleanValue : ()Z
    //   205: ifeq -> 216
    //   208: aload #7
    //   210: invokevirtual cancelTransaction : ()V
    //   213: goto -> 221
    //   216: aload #7
    //   218: invokevirtual completeTransaction : ()V
    //   221: iload #6
    //   223: iconst_1
    //   224: iadd
    //   225: istore_3
    //   226: iload #5
    //   228: istore #4
    //   230: goto -> 26
    //   233: return
  }
  
  private Fragment findFragmentUnder(Fragment paramFragment) {
    ViewGroup viewGroup = paramFragment.mContainer;
    View view = paramFragment.mView;
    if (viewGroup != null) {
      if (view == null)
        return null; 
      for (int i = this.mAdded.indexOf(paramFragment) - 1; i >= 0; i--) {
        paramFragment = this.mAdded.get(i);
        if (paramFragment.mContainer == viewGroup && paramFragment.mView != null)
          return paramFragment; 
      } 
    } 
    return null;
  }
  
  private void forcePostponedTransactions() {
    if (this.mPostponedTransactions != null)
      while (!this.mPostponedTransactions.isEmpty())
        ((StartEnterTransitionListener)this.mPostponedTransactions.remove(0)).completeTransaction();  
  }
  
  private boolean generateOpsForPendingActions(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mPendingActions : Ljava/util/ArrayList;
    //   6: astore #6
    //   8: iconst_0
    //   9: istore_3
    //   10: aload #6
    //   12: ifnull -> 102
    //   15: aload_0
    //   16: getfield mPendingActions : Ljava/util/ArrayList;
    //   19: invokevirtual size : ()I
    //   22: ifne -> 28
    //   25: goto -> 102
    //   28: aload_0
    //   29: getfield mPendingActions : Ljava/util/ArrayList;
    //   32: invokevirtual size : ()I
    //   35: istore #4
    //   37: iconst_0
    //   38: istore #5
    //   40: iload_3
    //   41: iload #4
    //   43: if_icmpge -> 76
    //   46: iload #5
    //   48: aload_0
    //   49: getfield mPendingActions : Ljava/util/ArrayList;
    //   52: iload_3
    //   53: invokevirtual get : (I)Ljava/lang/Object;
    //   56: checkcast androidx/fragment/app/FragmentManagerImpl$OpGenerator
    //   59: aload_1
    //   60: aload_2
    //   61: invokeinterface generateOps : (Ljava/util/ArrayList;Ljava/util/ArrayList;)Z
    //   66: ior
    //   67: istore #5
    //   69: iload_3
    //   70: iconst_1
    //   71: iadd
    //   72: istore_3
    //   73: goto -> 40
    //   76: aload_0
    //   77: getfield mPendingActions : Ljava/util/ArrayList;
    //   80: invokevirtual clear : ()V
    //   83: aload_0
    //   84: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   87: invokevirtual getHandler : ()Landroid/os/Handler;
    //   90: aload_0
    //   91: getfield mExecCommit : Ljava/lang/Runnable;
    //   94: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   97: aload_0
    //   98: monitorexit
    //   99: iload #5
    //   101: ireturn
    //   102: aload_0
    //   103: monitorexit
    //   104: iconst_0
    //   105: ireturn
    //   106: astore_1
    //   107: aload_0
    //   108: monitorexit
    //   109: goto -> 114
    //   112: aload_1
    //   113: athrow
    //   114: goto -> 112
    // Exception table:
    //   from	to	target	type
    //   2	8	106	finally
    //   15	25	106	finally
    //   28	37	106	finally
    //   46	69	106	finally
    //   76	99	106	finally
    //   102	104	106	finally
    //   107	109	106	finally
  }
  
  private static Animation.AnimationListener getAnimationListener(Animation paramAnimation) {
    try {
      if (sAnimationListenerField == null) {
        Field field = Animation.class.getDeclaredField("mListener");
        sAnimationListenerField = field;
        field.setAccessible(true);
      } 
      return (Animation.AnimationListener)sAnimationListenerField.get(paramAnimation);
    } catch (NoSuchFieldException noSuchFieldException) {
      Log.e("FragmentManager", "No field with the name mListener is found in Animation class", noSuchFieldException);
    } catch (IllegalAccessException illegalAccessException) {
      Log.e("FragmentManager", "Cannot access Animation's mListener field", illegalAccessException);
    } 
    return null;
  }
  
  static AnimationOrAnimator makeFadeAnimation(Context paramContext, float paramFloat1, float paramFloat2) {
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat1, paramFloat2);
    alphaAnimation.setInterpolator(DECELERATE_CUBIC);
    alphaAnimation.setDuration(220L);
    return new AnimationOrAnimator((Animation)alphaAnimation);
  }
  
  static AnimationOrAnimator makeOpenCloseAnimation(Context paramContext, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    AnimationSet animationSet = new AnimationSet(false);
    ScaleAnimation scaleAnimation = new ScaleAnimation(paramFloat1, paramFloat2, paramFloat1, paramFloat2, 1, 0.5F, 1, 0.5F);
    scaleAnimation.setInterpolator(DECELERATE_QUINT);
    scaleAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)scaleAnimation);
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat3, paramFloat4);
    alphaAnimation.setInterpolator(DECELERATE_CUBIC);
    alphaAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)alphaAnimation);
    return new AnimationOrAnimator((Animation)animationSet);
  }
  
  private void makeRemovedFragmentsInvisible(ArraySet<Fragment> paramArraySet) {
    int j = paramArraySet.size();
    for (int i = 0; i < j; i++) {
      Fragment fragment = (Fragment)paramArraySet.valueAt(i);
      if (!fragment.mAdded) {
        View view = fragment.getView();
        fragment.mPostponedAlpha = view.getAlpha();
        view.setAlpha(0.0F);
      } 
    } 
  }
  
  static boolean modifiesAlpha(Animator paramAnimator) {
    PropertyValuesHolder[] arrayOfPropertyValuesHolder;
    if (paramAnimator == null)
      return false; 
    if (paramAnimator instanceof ValueAnimator) {
      arrayOfPropertyValuesHolder = ((ValueAnimator)paramAnimator).getValues();
      for (int i = 0; i < arrayOfPropertyValuesHolder.length; i++) {
        if ("alpha".equals(arrayOfPropertyValuesHolder[i].getPropertyName()))
          return true; 
      } 
    } else if (arrayOfPropertyValuesHolder instanceof AnimatorSet) {
      ArrayList<Animator> arrayList = ((AnimatorSet)arrayOfPropertyValuesHolder).getChildAnimations();
      for (int i = 0; i < arrayList.size(); i++) {
        if (modifiesAlpha(arrayList.get(i)))
          return true; 
      } 
    } 
    return false;
  }
  
  static boolean modifiesAlpha(AnimationOrAnimator paramAnimationOrAnimator) {
    List list;
    if (paramAnimationOrAnimator.animation instanceof AlphaAnimation)
      return true; 
    if (paramAnimationOrAnimator.animation instanceof AnimationSet) {
      list = ((AnimationSet)paramAnimationOrAnimator.animation).getAnimations();
      for (int i = 0; i < list.size(); i++) {
        if (list.get(i) instanceof AlphaAnimation)
          return true; 
      } 
      return false;
    } 
    return modifiesAlpha(((AnimationOrAnimator)list).animator);
  }
  
  private boolean popBackStackImmediate(String paramString, int paramInt1, int paramInt2) {
    execPendingActions();
    ensureExecReady(true);
    Fragment fragment = this.mPrimaryNav;
    if (fragment != null && paramInt1 < 0 && paramString == null) {
      FragmentManager fragmentManager = fragment.peekChildFragmentManager();
      if (fragmentManager != null && fragmentManager.popBackStackImmediate())
        return true; 
    } 
    boolean bool = popBackStackState(this.mTmpRecords, this.mTmpIsPop, paramString, paramInt1, paramInt2);
    if (bool) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
      } finally {
        cleanupExec();
      } 
    } 
    doPendingDeferredStart();
    burpActive();
    return bool;
  }
  
  private int postponePostponableTransactions(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2, ArraySet<Fragment> paramArraySet) {
    int i = paramInt2 - 1;
    int j;
    for (j = paramInt2; i >= paramInt1; j = k) {
      boolean bool;
      BackStackRecord backStackRecord = paramArrayList.get(i);
      boolean bool1 = ((Boolean)paramArrayList1.get(i)).booleanValue();
      if (backStackRecord.isPostponed() && !backStackRecord.interactsWith(paramArrayList, i + 1, paramInt2)) {
        bool = true;
      } else {
        bool = false;
      } 
      int k = j;
      if (bool) {
        if (this.mPostponedTransactions == null)
          this.mPostponedTransactions = new ArrayList<StartEnterTransitionListener>(); 
        StartEnterTransitionListener startEnterTransitionListener = new StartEnterTransitionListener(backStackRecord, bool1);
        this.mPostponedTransactions.add(startEnterTransitionListener);
        backStackRecord.setOnStartPostponedListener(startEnterTransitionListener);
        if (bool1) {
          backStackRecord.executeOps();
        } else {
          backStackRecord.executePopOps(false);
        } 
        k = j - 1;
        if (i != k) {
          paramArrayList.remove(i);
          paramArrayList.add(k, backStackRecord);
        } 
        addAddedFragments(paramArraySet);
      } 
      i--;
    } 
    return j;
  }
  
  private void removeRedundantOperationsAndExecute(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (paramArrayList != null) {
      if (paramArrayList.isEmpty())
        return; 
      if (paramArrayList1 != null && paramArrayList.size() == paramArrayList1.size()) {
        executePostponedTransaction(paramArrayList, paramArrayList1);
        int k = paramArrayList.size();
        int i = 0;
        int j;
        for (j = 0; i < k; j = m) {
          int n = i;
          int m = j;
          if (!((BackStackRecord)paramArrayList.get(i)).mReorderingAllowed) {
            if (j != i)
              executeOpsTogether(paramArrayList, paramArrayList1, j, i); 
            j = i + 1;
            m = j;
            if (((Boolean)paramArrayList1.get(i)).booleanValue())
              while (true) {
                m = j;
                if (j < k) {
                  m = j;
                  if (((Boolean)paramArrayList1.get(j)).booleanValue()) {
                    m = j;
                    if (!((BackStackRecord)paramArrayList.get(j)).mReorderingAllowed) {
                      j++;
                      continue;
                    } 
                  } 
                } 
                break;
              }  
            executeOpsTogether(paramArrayList, paramArrayList1, i, m);
            n = m - 1;
          } 
          i = n + 1;
        } 
        if (j != k)
          executeOpsTogether(paramArrayList, paramArrayList1, j, k); 
        return;
      } 
      throw new IllegalStateException("Internal error with the back stack records");
    } 
  }
  
  public static int reverseTransit(int paramInt) {
    char c = ' ';
    if (paramInt != 4097) {
      if (paramInt != 4099)
        return (paramInt != 8194) ? 0 : 4097; 
      c = 'ဃ';
    } 
    return c;
  }
  
  private static void setHWLayerAnimListenerIfAlpha(View paramView, AnimationOrAnimator paramAnimationOrAnimator) {
    if (paramView != null) {
      if (paramAnimationOrAnimator == null)
        return; 
      if (shouldRunOnHWLayer(paramView, paramAnimationOrAnimator)) {
        if (paramAnimationOrAnimator.animator != null) {
          paramAnimationOrAnimator.animator.addListener((Animator.AnimatorListener)new AnimatorOnHWLayerIfNeededListener(paramView));
          return;
        } 
        Animation.AnimationListener animationListener = getAnimationListener(paramAnimationOrAnimator.animation);
        paramView.setLayerType(2, null);
        paramAnimationOrAnimator.animation.setAnimationListener(new AnimateOnHWLayerIfNeededListener(paramView, animationListener));
      } 
    } 
  }
  
  private static void setRetaining(FragmentManagerNonConfig paramFragmentManagerNonConfig) {
    if (paramFragmentManagerNonConfig == null)
      return; 
    List<Fragment> list1 = paramFragmentManagerNonConfig.getFragments();
    if (list1 != null) {
      Iterator<Fragment> iterator = list1.iterator();
      while (iterator.hasNext())
        ((Fragment)iterator.next()).mRetaining = true; 
    } 
    List<FragmentManagerNonConfig> list = paramFragmentManagerNonConfig.getChildNonConfigs();
    if (list != null) {
      Iterator<FragmentManagerNonConfig> iterator = list.iterator();
      while (iterator.hasNext())
        setRetaining(iterator.next()); 
    } 
  }
  
  static boolean shouldRunOnHWLayer(View paramView, AnimationOrAnimator paramAnimationOrAnimator) {
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (paramView != null) {
      if (paramAnimationOrAnimator == null)
        return false; 
      bool1 = bool2;
      if (Build.VERSION.SDK_INT >= 19) {
        bool1 = bool2;
        if (paramView.getLayerType() == 0) {
          bool1 = bool2;
          if (ViewCompat.hasOverlappingRendering(paramView)) {
            bool1 = bool2;
            if (modifiesAlpha(paramAnimationOrAnimator))
              bool1 = true; 
          } 
        } 
      } 
    } 
    return bool1;
  }
  
  private void throwException(RuntimeException paramRuntimeException) {
    Log.e("FragmentManager", paramRuntimeException.getMessage());
    Log.e("FragmentManager", "Activity state:");
    PrintWriter printWriter = new PrintWriter((Writer)new LogWriter("FragmentManager"));
    FragmentHostCallback fragmentHostCallback = this.mHost;
    if (fragmentHostCallback != null) {
      try {
        fragmentHostCallback.onDump("  ", null, printWriter, new String[0]);
      } catch (Exception exception) {
        Log.e("FragmentManager", "Failed dumping state", exception);
      } 
    } else {
      try {
        dump("  ", null, (PrintWriter)exception, new String[0]);
      } catch (Exception exception1) {
        Log.e("FragmentManager", "Failed dumping state", exception1);
      } 
    } 
    throw paramRuntimeException;
  }
  
  public static int transitToStyleIndex(int paramInt, boolean paramBoolean) {
    return (paramInt != 4097) ? ((paramInt != 4099) ? ((paramInt != 8194) ? -1 : (paramBoolean ? 3 : 4)) : (paramBoolean ? 5 : 6)) : (paramBoolean ? 1 : 2);
  }
  
  void addBackStackState(BackStackRecord paramBackStackRecord) {
    if (this.mBackStack == null)
      this.mBackStack = new ArrayList<BackStackRecord>(); 
    this.mBackStack.add(paramBackStackRecord);
  }
  
  public void addFragment(Fragment paramFragment, boolean paramBoolean) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("add: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    makeActive(paramFragment);
    if (!paramFragment.mDetached)
      if (!this.mAdded.contains(paramFragment)) {
        synchronized (this.mAdded) {
          this.mAdded.add(paramFragment);
          paramFragment.mAdded = true;
          paramFragment.mRemoving = false;
          if (paramFragment.mView == null)
            paramFragment.mHiddenChanged = false; 
          if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
            this.mNeedMenuInvalidate = true; 
          if (paramBoolean) {
            moveToState(paramFragment);
            return;
          } 
        } 
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment already added: ");
        stringBuilder.append(paramFragment);
        throw new IllegalStateException(stringBuilder.toString());
      }  
  }
  
  public void addOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener paramOnBackStackChangedListener) {
    if (this.mBackStackChangeListeners == null)
      this.mBackStackChangeListeners = new ArrayList<FragmentManager.OnBackStackChangedListener>(); 
    this.mBackStackChangeListeners.add(paramOnBackStackChangedListener);
  }
  
  public int allocBackStackIndex(BackStackRecord paramBackStackRecord) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   6: ifnull -> 111
    //   9: aload_0
    //   10: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   13: invokevirtual size : ()I
    //   16: ifgt -> 22
    //   19: goto -> 111
    //   22: aload_0
    //   23: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   26: aload_0
    //   27: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   30: invokevirtual size : ()I
    //   33: iconst_1
    //   34: isub
    //   35: invokevirtual remove : (I)Ljava/lang/Object;
    //   38: checkcast java/lang/Integer
    //   41: invokevirtual intValue : ()I
    //   44: istore_2
    //   45: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   48: ifeq -> 97
    //   51: new java/lang/StringBuilder
    //   54: dup
    //   55: invokespecial <init> : ()V
    //   58: astore_3
    //   59: aload_3
    //   60: ldc_w 'Adding back stack index '
    //   63: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   66: pop
    //   67: aload_3
    //   68: iload_2
    //   69: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   72: pop
    //   73: aload_3
    //   74: ldc_w ' with '
    //   77: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   80: pop
    //   81: aload_3
    //   82: aload_1
    //   83: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   86: pop
    //   87: ldc 'FragmentManager'
    //   89: aload_3
    //   90: invokevirtual toString : ()Ljava/lang/String;
    //   93: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   96: pop
    //   97: aload_0
    //   98: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   101: iload_2
    //   102: aload_1
    //   103: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   106: pop
    //   107: aload_0
    //   108: monitorexit
    //   109: iload_2
    //   110: ireturn
    //   111: aload_0
    //   112: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   115: ifnonnull -> 129
    //   118: aload_0
    //   119: new java/util/ArrayList
    //   122: dup
    //   123: invokespecial <init> : ()V
    //   126: putfield mBackStackIndices : Ljava/util/ArrayList;
    //   129: aload_0
    //   130: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   133: invokevirtual size : ()I
    //   136: istore_2
    //   137: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   140: ifeq -> 189
    //   143: new java/lang/StringBuilder
    //   146: dup
    //   147: invokespecial <init> : ()V
    //   150: astore_3
    //   151: aload_3
    //   152: ldc_w 'Setting back stack index '
    //   155: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   158: pop
    //   159: aload_3
    //   160: iload_2
    //   161: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   164: pop
    //   165: aload_3
    //   166: ldc_w ' to '
    //   169: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   172: pop
    //   173: aload_3
    //   174: aload_1
    //   175: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   178: pop
    //   179: ldc 'FragmentManager'
    //   181: aload_3
    //   182: invokevirtual toString : ()Ljava/lang/String;
    //   185: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   188: pop
    //   189: aload_0
    //   190: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   193: aload_1
    //   194: invokevirtual add : (Ljava/lang/Object;)Z
    //   197: pop
    //   198: aload_0
    //   199: monitorexit
    //   200: iload_2
    //   201: ireturn
    //   202: astore_1
    //   203: aload_0
    //   204: monitorexit
    //   205: aload_1
    //   206: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	202	finally
    //   22	97	202	finally
    //   97	109	202	finally
    //   111	129	202	finally
    //   129	189	202	finally
    //   189	200	202	finally
    //   203	205	202	finally
  }
  
  public void attachController(FragmentHostCallback paramFragmentHostCallback, FragmentContainer paramFragmentContainer, Fragment paramFragment) {
    if (this.mHost == null) {
      this.mHost = paramFragmentHostCallback;
      this.mContainer = paramFragmentContainer;
      this.mParent = paramFragment;
      return;
    } 
    throw new IllegalStateException("Already attached");
  }
  
  public void attachFragment(Fragment paramFragment) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("attach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mDetached) {
      paramFragment.mDetached = false;
      if (!paramFragment.mAdded)
        if (!this.mAdded.contains(paramFragment)) {
          if (DEBUG) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("add from attach: ");
            stringBuilder.append(paramFragment);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          synchronized (this.mAdded) {
            this.mAdded.add(paramFragment);
            paramFragment.mAdded = true;
            if (paramFragment.mHasMenu && paramFragment.mMenuVisible) {
              this.mNeedMenuInvalidate = true;
              return;
            } 
          } 
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Fragment already added: ");
          stringBuilder.append(paramFragment);
          throw new IllegalStateException(stringBuilder.toString());
        }  
    } 
  }
  
  public FragmentTransaction beginTransaction() {
    return new BackStackRecord(this);
  }
  
  void completeExecute(BackStackRecord paramBackStackRecord, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    if (paramBoolean1) {
      paramBackStackRecord.executePopOps(paramBoolean3);
    } else {
      paramBackStackRecord.executeOps();
    } 
    ArrayList<BackStackRecord> arrayList = new ArrayList(1);
    ArrayList<Boolean> arrayList1 = new ArrayList(1);
    arrayList.add(paramBackStackRecord);
    arrayList1.add(Boolean.valueOf(paramBoolean1));
    if (paramBoolean2)
      FragmentTransition.startTransitions(this, arrayList, arrayList1, 0, 1, true); 
    if (paramBoolean3)
      moveToState(this.mCurState, true); 
    SparseArray<Fragment> sparseArray = this.mActive;
    if (sparseArray != null) {
      int j = sparseArray.size();
      int i;
      for (i = 0; i < j; i++) {
        Fragment fragment = (Fragment)this.mActive.valueAt(i);
        if (fragment != null && fragment.mView != null && fragment.mIsNewlyAdded && paramBackStackRecord.interactsWith(fragment.mContainerId)) {
          if (fragment.mPostponedAlpha > 0.0F)
            fragment.mView.setAlpha(fragment.mPostponedAlpha); 
          if (paramBoolean3) {
            fragment.mPostponedAlpha = 0.0F;
          } else {
            fragment.mPostponedAlpha = -1.0F;
            fragment.mIsNewlyAdded = false;
          } 
        } 
      } 
    } 
  }
  
  void completeShowHideFragment(final Fragment fragment) {
    if (fragment.mView != null) {
      AnimationOrAnimator animationOrAnimator = loadAnimation(fragment, fragment.getNextTransition(), fragment.mHidden ^ true, fragment.getNextTransitionStyle());
      if (animationOrAnimator != null && animationOrAnimator.animator != null) {
        animationOrAnimator.animator.setTarget(fragment.mView);
        if (fragment.mHidden) {
          if (fragment.isHideReplaced()) {
            fragment.setHideReplaced(false);
          } else {
            final ViewGroup container = fragment.mContainer;
            final View animatingView = fragment.mView;
            viewGroup.startViewTransition(view);
            animationOrAnimator.animator.addListener((Animator.AnimatorListener)new AnimatorListenerAdapter() {
                  public void onAnimationEnd(Animator param1Animator) {
                    container.endViewTransition(animatingView);
                    param1Animator.removeListener((Animator.AnimatorListener)this);
                    if (fragment.mView != null)
                      fragment.mView.setVisibility(8); 
                  }
                });
          } 
        } else {
          fragment.mView.setVisibility(0);
        } 
        setHWLayerAnimListenerIfAlpha(fragment.mView, animationOrAnimator);
        animationOrAnimator.animator.start();
      } else {
        boolean bool;
        if (animationOrAnimator != null) {
          setHWLayerAnimListenerIfAlpha(fragment.mView, animationOrAnimator);
          fragment.mView.startAnimation(animationOrAnimator.animation);
          animationOrAnimator.animation.start();
        } 
        if (fragment.mHidden && !fragment.isHideReplaced()) {
          bool = true;
        } else {
          bool = false;
        } 
        fragment.mView.setVisibility(bool);
        if (fragment.isHideReplaced())
          fragment.setHideReplaced(false); 
      } 
    } 
    if (fragment.mAdded && fragment.mHasMenu && fragment.mMenuVisible)
      this.mNeedMenuInvalidate = true; 
    fragment.mHiddenChanged = false;
    fragment.onHiddenChanged(fragment.mHidden);
  }
  
  public void detachFragment(Fragment paramFragment) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("detach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mDetached) {
      paramFragment.mDetached = true;
      if (paramFragment.mAdded) {
        if (DEBUG) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("remove from detach: ");
          stringBuilder.append(paramFragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        synchronized (this.mAdded) {
          this.mAdded.remove(paramFragment);
          if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
            this.mNeedMenuInvalidate = true; 
          paramFragment.mAdded = false;
          return;
        } 
      } 
    } 
  }
  
  public void dispatchActivityCreated() {
    this.mStateSaved = false;
    this.mStopped = false;
    dispatchStateChange(2);
  }
  
  public void dispatchConfigurationChanged(Configuration paramConfiguration) {
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performConfigurationChanged(paramConfiguration); 
    } 
  }
  
  public boolean dispatchContextItemSelected(MenuItem paramMenuItem) {
    if (this.mCurState < 1)
      return false; 
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null && fragment.performContextItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void dispatchCreate() {
    this.mStateSaved = false;
    this.mStopped = false;
    dispatchStateChange(1);
  }
  
  public boolean dispatchCreateOptionsMenu(Menu paramMenu, MenuInflater paramMenuInflater) {
    int i = this.mCurState;
    boolean bool1 = false;
    if (i < 1)
      return false; 
    ArrayList<Fragment> arrayList = null;
    i = 0;
    boolean bool2;
    for (bool2 = false; i < this.mAdded.size(); bool2 = bool) {
      Fragment fragment = this.mAdded.get(i);
      ArrayList<Fragment> arrayList1 = arrayList;
      boolean bool = bool2;
      if (fragment != null) {
        arrayList1 = arrayList;
        bool = bool2;
        if (fragment.performCreateOptionsMenu(paramMenu, paramMenuInflater)) {
          arrayList1 = arrayList;
          if (arrayList == null)
            arrayList1 = new ArrayList(); 
          arrayList1.add(fragment);
          bool = true;
        } 
      } 
      i++;
      arrayList = arrayList1;
    } 
    if (this.mCreatedMenus != null)
      for (i = bool1; i < this.mCreatedMenus.size(); i++) {
        Fragment fragment = this.mCreatedMenus.get(i);
        if (arrayList == null || !arrayList.contains(fragment))
          fragment.onDestroyOptionsMenu(); 
      }  
    this.mCreatedMenus = arrayList;
    return bool2;
  }
  
  public void dispatchDestroy() {
    this.mDestroyed = true;
    execPendingActions();
    dispatchStateChange(0);
    this.mHost = null;
    this.mContainer = null;
    this.mParent = null;
  }
  
  public void dispatchDestroyView() {
    dispatchStateChange(1);
  }
  
  public void dispatchLowMemory() {
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performLowMemory(); 
    } 
  }
  
  public void dispatchMultiWindowModeChanged(boolean paramBoolean) {
    for (int i = this.mAdded.size() - 1; i >= 0; i--) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performMultiWindowModeChanged(paramBoolean); 
    } 
  }
  
  void dispatchOnFragmentActivityCreated(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentActivityCreated(paramFragment, paramBundle, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentActivityCreated(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentAttached(Fragment paramFragment, Context paramContext, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentAttached(paramFragment, paramContext, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentAttached(this, paramFragment, paramContext); 
    } 
  }
  
  void dispatchOnFragmentCreated(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentCreated(paramFragment, paramBundle, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentCreated(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentDestroyed(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentDestroyed(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentDestroyed(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentDetached(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentDetached(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentDetached(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentPaused(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentPaused(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentPaused(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentPreAttached(Fragment paramFragment, Context paramContext, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentPreAttached(paramFragment, paramContext, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentPreAttached(this, paramFragment, paramContext); 
    } 
  }
  
  void dispatchOnFragmentPreCreated(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentPreCreated(paramFragment, paramBundle, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentPreCreated(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentResumed(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentResumed(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentResumed(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentSaveInstanceState(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentSaveInstanceState(paramFragment, paramBundle, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentSaveInstanceState(this, paramFragment, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentStarted(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentStarted(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentStarted(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentStopped(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentStopped(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentStopped(this, paramFragment); 
    } 
  }
  
  void dispatchOnFragmentViewCreated(Fragment paramFragment, View paramView, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentViewCreated(paramFragment, paramView, paramBundle, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentViewCreated(this, paramFragment, paramView, paramBundle); 
    } 
  }
  
  void dispatchOnFragmentViewDestroyed(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.mParent;
    if (fragment != null) {
      FragmentManager fragmentManager = fragment.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).dispatchOnFragmentViewDestroyed(paramFragment, true); 
    } 
    for (FragmentLifecycleCallbacksHolder fragmentLifecycleCallbacksHolder : this.mLifecycleCallbacks) {
      if (!paramBoolean || fragmentLifecycleCallbacksHolder.mRecursive)
        fragmentLifecycleCallbacksHolder.mCallback.onFragmentViewDestroyed(this, paramFragment); 
    } 
  }
  
  public boolean dispatchOptionsItemSelected(MenuItem paramMenuItem) {
    if (this.mCurState < 1)
      return false; 
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null && fragment.performOptionsItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void dispatchOptionsMenuClosed(Menu paramMenu) {
    if (this.mCurState < 1)
      return; 
    for (int i = 0; i < this.mAdded.size(); i++) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performOptionsMenuClosed(paramMenu); 
    } 
  }
  
  public void dispatchPause() {
    dispatchStateChange(3);
  }
  
  public void dispatchPictureInPictureModeChanged(boolean paramBoolean) {
    for (int i = this.mAdded.size() - 1; i >= 0; i--) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.performPictureInPictureModeChanged(paramBoolean); 
    } 
  }
  
  public boolean dispatchPrepareOptionsMenu(Menu paramMenu) {
    int j = this.mCurState;
    int i = 0;
    if (j < 1)
      return false; 
    boolean bool;
    for (bool = false; i < this.mAdded.size(); bool = bool1) {
      Fragment fragment = this.mAdded.get(i);
      boolean bool1 = bool;
      if (fragment != null) {
        bool1 = bool;
        if (fragment.performPrepareOptionsMenu(paramMenu))
          bool1 = true; 
      } 
      i++;
    } 
    return bool;
  }
  
  public void dispatchResume() {
    this.mStateSaved = false;
    this.mStopped = false;
    dispatchStateChange(4);
  }
  
  public void dispatchStart() {
    this.mStateSaved = false;
    this.mStopped = false;
    dispatchStateChange(3);
  }
  
  public void dispatchStop() {
    this.mStopped = true;
    dispatchStateChange(2);
  }
  
  void doPendingDeferredStart() {
    if (this.mHavePendingDeferredStart) {
      this.mHavePendingDeferredStart = false;
      startPendingDeferredFragments();
    } 
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #8
    //   9: aload #8
    //   11: aload_1
    //   12: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   15: pop
    //   16: aload #8
    //   18: ldc_w '    '
    //   21: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   24: pop
    //   25: aload #8
    //   27: invokevirtual toString : ()Ljava/lang/String;
    //   30: astore #8
    //   32: aload_0
    //   33: getfield mActive : Landroid/util/SparseArray;
    //   36: astore #9
    //   38: iconst_0
    //   39: istore #6
    //   41: aload #9
    //   43: ifnull -> 168
    //   46: aload #9
    //   48: invokevirtual size : ()I
    //   51: istore #7
    //   53: iload #7
    //   55: ifle -> 168
    //   58: aload_3
    //   59: aload_1
    //   60: invokevirtual print : (Ljava/lang/String;)V
    //   63: aload_3
    //   64: ldc_w 'Active Fragments in '
    //   67: invokevirtual print : (Ljava/lang/String;)V
    //   70: aload_3
    //   71: aload_0
    //   72: invokestatic identityHashCode : (Ljava/lang/Object;)I
    //   75: invokestatic toHexString : (I)Ljava/lang/String;
    //   78: invokevirtual print : (Ljava/lang/String;)V
    //   81: aload_3
    //   82: ldc_w ':'
    //   85: invokevirtual println : (Ljava/lang/String;)V
    //   88: iconst_0
    //   89: istore #5
    //   91: iload #5
    //   93: iload #7
    //   95: if_icmpge -> 168
    //   98: aload_0
    //   99: getfield mActive : Landroid/util/SparseArray;
    //   102: iload #5
    //   104: invokevirtual valueAt : (I)Ljava/lang/Object;
    //   107: checkcast androidx/fragment/app/Fragment
    //   110: astore #9
    //   112: aload_3
    //   113: aload_1
    //   114: invokevirtual print : (Ljava/lang/String;)V
    //   117: aload_3
    //   118: ldc_w '  #'
    //   121: invokevirtual print : (Ljava/lang/String;)V
    //   124: aload_3
    //   125: iload #5
    //   127: invokevirtual print : (I)V
    //   130: aload_3
    //   131: ldc_w ': '
    //   134: invokevirtual print : (Ljava/lang/String;)V
    //   137: aload_3
    //   138: aload #9
    //   140: invokevirtual println : (Ljava/lang/Object;)V
    //   143: aload #9
    //   145: ifnull -> 159
    //   148: aload #9
    //   150: aload #8
    //   152: aload_2
    //   153: aload_3
    //   154: aload #4
    //   156: invokevirtual dump : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   159: iload #5
    //   161: iconst_1
    //   162: iadd
    //   163: istore #5
    //   165: goto -> 91
    //   168: aload_0
    //   169: getfield mAdded : Ljava/util/ArrayList;
    //   172: invokevirtual size : ()I
    //   175: istore #7
    //   177: iload #7
    //   179: ifle -> 261
    //   182: aload_3
    //   183: aload_1
    //   184: invokevirtual print : (Ljava/lang/String;)V
    //   187: aload_3
    //   188: ldc_w 'Added Fragments:'
    //   191: invokevirtual println : (Ljava/lang/String;)V
    //   194: iconst_0
    //   195: istore #5
    //   197: iload #5
    //   199: iload #7
    //   201: if_icmpge -> 261
    //   204: aload_0
    //   205: getfield mAdded : Ljava/util/ArrayList;
    //   208: iload #5
    //   210: invokevirtual get : (I)Ljava/lang/Object;
    //   213: checkcast androidx/fragment/app/Fragment
    //   216: astore #9
    //   218: aload_3
    //   219: aload_1
    //   220: invokevirtual print : (Ljava/lang/String;)V
    //   223: aload_3
    //   224: ldc_w '  #'
    //   227: invokevirtual print : (Ljava/lang/String;)V
    //   230: aload_3
    //   231: iload #5
    //   233: invokevirtual print : (I)V
    //   236: aload_3
    //   237: ldc_w ': '
    //   240: invokevirtual print : (Ljava/lang/String;)V
    //   243: aload_3
    //   244: aload #9
    //   246: invokevirtual toString : ()Ljava/lang/String;
    //   249: invokevirtual println : (Ljava/lang/String;)V
    //   252: iload #5
    //   254: iconst_1
    //   255: iadd
    //   256: istore #5
    //   258: goto -> 197
    //   261: aload_0
    //   262: getfield mCreatedMenus : Ljava/util/ArrayList;
    //   265: astore #9
    //   267: aload #9
    //   269: ifnull -> 363
    //   272: aload #9
    //   274: invokevirtual size : ()I
    //   277: istore #7
    //   279: iload #7
    //   281: ifle -> 363
    //   284: aload_3
    //   285: aload_1
    //   286: invokevirtual print : (Ljava/lang/String;)V
    //   289: aload_3
    //   290: ldc_w 'Fragments Created Menus:'
    //   293: invokevirtual println : (Ljava/lang/String;)V
    //   296: iconst_0
    //   297: istore #5
    //   299: iload #5
    //   301: iload #7
    //   303: if_icmpge -> 363
    //   306: aload_0
    //   307: getfield mCreatedMenus : Ljava/util/ArrayList;
    //   310: iload #5
    //   312: invokevirtual get : (I)Ljava/lang/Object;
    //   315: checkcast androidx/fragment/app/Fragment
    //   318: astore #9
    //   320: aload_3
    //   321: aload_1
    //   322: invokevirtual print : (Ljava/lang/String;)V
    //   325: aload_3
    //   326: ldc_w '  #'
    //   329: invokevirtual print : (Ljava/lang/String;)V
    //   332: aload_3
    //   333: iload #5
    //   335: invokevirtual print : (I)V
    //   338: aload_3
    //   339: ldc_w ': '
    //   342: invokevirtual print : (Ljava/lang/String;)V
    //   345: aload_3
    //   346: aload #9
    //   348: invokevirtual toString : ()Ljava/lang/String;
    //   351: invokevirtual println : (Ljava/lang/String;)V
    //   354: iload #5
    //   356: iconst_1
    //   357: iadd
    //   358: istore #5
    //   360: goto -> 299
    //   363: aload_0
    //   364: getfield mBackStack : Ljava/util/ArrayList;
    //   367: astore #9
    //   369: aload #9
    //   371: ifnull -> 476
    //   374: aload #9
    //   376: invokevirtual size : ()I
    //   379: istore #7
    //   381: iload #7
    //   383: ifle -> 476
    //   386: aload_3
    //   387: aload_1
    //   388: invokevirtual print : (Ljava/lang/String;)V
    //   391: aload_3
    //   392: ldc_w 'Back Stack:'
    //   395: invokevirtual println : (Ljava/lang/String;)V
    //   398: iconst_0
    //   399: istore #5
    //   401: iload #5
    //   403: iload #7
    //   405: if_icmpge -> 476
    //   408: aload_0
    //   409: getfield mBackStack : Ljava/util/ArrayList;
    //   412: iload #5
    //   414: invokevirtual get : (I)Ljava/lang/Object;
    //   417: checkcast androidx/fragment/app/BackStackRecord
    //   420: astore #9
    //   422: aload_3
    //   423: aload_1
    //   424: invokevirtual print : (Ljava/lang/String;)V
    //   427: aload_3
    //   428: ldc_w '  #'
    //   431: invokevirtual print : (Ljava/lang/String;)V
    //   434: aload_3
    //   435: iload #5
    //   437: invokevirtual print : (I)V
    //   440: aload_3
    //   441: ldc_w ': '
    //   444: invokevirtual print : (Ljava/lang/String;)V
    //   447: aload_3
    //   448: aload #9
    //   450: invokevirtual toString : ()Ljava/lang/String;
    //   453: invokevirtual println : (Ljava/lang/String;)V
    //   456: aload #9
    //   458: aload #8
    //   460: aload_2
    //   461: aload_3
    //   462: aload #4
    //   464: invokevirtual dump : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   467: iload #5
    //   469: iconst_1
    //   470: iadd
    //   471: istore #5
    //   473: goto -> 401
    //   476: aload_0
    //   477: monitorenter
    //   478: aload_0
    //   479: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   482: ifnull -> 573
    //   485: aload_0
    //   486: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   489: invokevirtual size : ()I
    //   492: istore #7
    //   494: iload #7
    //   496: ifle -> 573
    //   499: aload_3
    //   500: aload_1
    //   501: invokevirtual print : (Ljava/lang/String;)V
    //   504: aload_3
    //   505: ldc_w 'Back Stack Indices:'
    //   508: invokevirtual println : (Ljava/lang/String;)V
    //   511: iconst_0
    //   512: istore #5
    //   514: iload #5
    //   516: iload #7
    //   518: if_icmpge -> 573
    //   521: aload_0
    //   522: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   525: iload #5
    //   527: invokevirtual get : (I)Ljava/lang/Object;
    //   530: checkcast androidx/fragment/app/BackStackRecord
    //   533: astore_2
    //   534: aload_3
    //   535: aload_1
    //   536: invokevirtual print : (Ljava/lang/String;)V
    //   539: aload_3
    //   540: ldc_w '  #'
    //   543: invokevirtual print : (Ljava/lang/String;)V
    //   546: aload_3
    //   547: iload #5
    //   549: invokevirtual print : (I)V
    //   552: aload_3
    //   553: ldc_w ': '
    //   556: invokevirtual print : (Ljava/lang/String;)V
    //   559: aload_3
    //   560: aload_2
    //   561: invokevirtual println : (Ljava/lang/Object;)V
    //   564: iload #5
    //   566: iconst_1
    //   567: iadd
    //   568: istore #5
    //   570: goto -> 514
    //   573: aload_0
    //   574: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   577: ifnull -> 616
    //   580: aload_0
    //   581: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   584: invokevirtual size : ()I
    //   587: ifle -> 616
    //   590: aload_3
    //   591: aload_1
    //   592: invokevirtual print : (Ljava/lang/String;)V
    //   595: aload_3
    //   596: ldc_w 'mAvailBackStackIndices: '
    //   599: invokevirtual print : (Ljava/lang/String;)V
    //   602: aload_3
    //   603: aload_0
    //   604: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   607: invokevirtual toArray : ()[Ljava/lang/Object;
    //   610: invokestatic toString : ([Ljava/lang/Object;)Ljava/lang/String;
    //   613: invokevirtual println : (Ljava/lang/String;)V
    //   616: aload_0
    //   617: monitorexit
    //   618: aload_0
    //   619: getfield mPendingActions : Ljava/util/ArrayList;
    //   622: astore_2
    //   623: aload_2
    //   624: ifnull -> 713
    //   627: aload_2
    //   628: invokevirtual size : ()I
    //   631: istore #7
    //   633: iload #7
    //   635: ifle -> 713
    //   638: aload_3
    //   639: aload_1
    //   640: invokevirtual print : (Ljava/lang/String;)V
    //   643: aload_3
    //   644: ldc_w 'Pending Actions:'
    //   647: invokevirtual println : (Ljava/lang/String;)V
    //   650: iload #6
    //   652: istore #5
    //   654: iload #5
    //   656: iload #7
    //   658: if_icmpge -> 713
    //   661: aload_0
    //   662: getfield mPendingActions : Ljava/util/ArrayList;
    //   665: iload #5
    //   667: invokevirtual get : (I)Ljava/lang/Object;
    //   670: checkcast androidx/fragment/app/FragmentManagerImpl$OpGenerator
    //   673: astore_2
    //   674: aload_3
    //   675: aload_1
    //   676: invokevirtual print : (Ljava/lang/String;)V
    //   679: aload_3
    //   680: ldc_w '  #'
    //   683: invokevirtual print : (Ljava/lang/String;)V
    //   686: aload_3
    //   687: iload #5
    //   689: invokevirtual print : (I)V
    //   692: aload_3
    //   693: ldc_w ': '
    //   696: invokevirtual print : (Ljava/lang/String;)V
    //   699: aload_3
    //   700: aload_2
    //   701: invokevirtual println : (Ljava/lang/Object;)V
    //   704: iload #5
    //   706: iconst_1
    //   707: iadd
    //   708: istore #5
    //   710: goto -> 654
    //   713: aload_3
    //   714: aload_1
    //   715: invokevirtual print : (Ljava/lang/String;)V
    //   718: aload_3
    //   719: ldc_w 'FragmentManager misc state:'
    //   722: invokevirtual println : (Ljava/lang/String;)V
    //   725: aload_3
    //   726: aload_1
    //   727: invokevirtual print : (Ljava/lang/String;)V
    //   730: aload_3
    //   731: ldc_w '  mHost='
    //   734: invokevirtual print : (Ljava/lang/String;)V
    //   737: aload_3
    //   738: aload_0
    //   739: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   742: invokevirtual println : (Ljava/lang/Object;)V
    //   745: aload_3
    //   746: aload_1
    //   747: invokevirtual print : (Ljava/lang/String;)V
    //   750: aload_3
    //   751: ldc_w '  mContainer='
    //   754: invokevirtual print : (Ljava/lang/String;)V
    //   757: aload_3
    //   758: aload_0
    //   759: getfield mContainer : Landroidx/fragment/app/FragmentContainer;
    //   762: invokevirtual println : (Ljava/lang/Object;)V
    //   765: aload_0
    //   766: getfield mParent : Landroidx/fragment/app/Fragment;
    //   769: ifnull -> 792
    //   772: aload_3
    //   773: aload_1
    //   774: invokevirtual print : (Ljava/lang/String;)V
    //   777: aload_3
    //   778: ldc_w '  mParent='
    //   781: invokevirtual print : (Ljava/lang/String;)V
    //   784: aload_3
    //   785: aload_0
    //   786: getfield mParent : Landroidx/fragment/app/Fragment;
    //   789: invokevirtual println : (Ljava/lang/Object;)V
    //   792: aload_3
    //   793: aload_1
    //   794: invokevirtual print : (Ljava/lang/String;)V
    //   797: aload_3
    //   798: ldc_w '  mCurState='
    //   801: invokevirtual print : (Ljava/lang/String;)V
    //   804: aload_3
    //   805: aload_0
    //   806: getfield mCurState : I
    //   809: invokevirtual print : (I)V
    //   812: aload_3
    //   813: ldc_w ' mStateSaved='
    //   816: invokevirtual print : (Ljava/lang/String;)V
    //   819: aload_3
    //   820: aload_0
    //   821: getfield mStateSaved : Z
    //   824: invokevirtual print : (Z)V
    //   827: aload_3
    //   828: ldc_w ' mStopped='
    //   831: invokevirtual print : (Ljava/lang/String;)V
    //   834: aload_3
    //   835: aload_0
    //   836: getfield mStopped : Z
    //   839: invokevirtual print : (Z)V
    //   842: aload_3
    //   843: ldc_w ' mDestroyed='
    //   846: invokevirtual print : (Ljava/lang/String;)V
    //   849: aload_3
    //   850: aload_0
    //   851: getfield mDestroyed : Z
    //   854: invokevirtual println : (Z)V
    //   857: aload_0
    //   858: getfield mNeedMenuInvalidate : Z
    //   861: ifeq -> 884
    //   864: aload_3
    //   865: aload_1
    //   866: invokevirtual print : (Ljava/lang/String;)V
    //   869: aload_3
    //   870: ldc_w '  mNeedMenuInvalidate='
    //   873: invokevirtual print : (Ljava/lang/String;)V
    //   876: aload_3
    //   877: aload_0
    //   878: getfield mNeedMenuInvalidate : Z
    //   881: invokevirtual println : (Z)V
    //   884: aload_0
    //   885: getfield mNoTransactionsBecause : Ljava/lang/String;
    //   888: ifnull -> 911
    //   891: aload_3
    //   892: aload_1
    //   893: invokevirtual print : (Ljava/lang/String;)V
    //   896: aload_3
    //   897: ldc_w '  mNoTransactionsBecause='
    //   900: invokevirtual print : (Ljava/lang/String;)V
    //   903: aload_3
    //   904: aload_0
    //   905: getfield mNoTransactionsBecause : Ljava/lang/String;
    //   908: invokevirtual println : (Ljava/lang/String;)V
    //   911: return
    //   912: astore_1
    //   913: aload_0
    //   914: monitorexit
    //   915: goto -> 920
    //   918: aload_1
    //   919: athrow
    //   920: goto -> 918
    // Exception table:
    //   from	to	target	type
    //   478	494	912	finally
    //   499	511	912	finally
    //   521	564	912	finally
    //   573	616	912	finally
    //   616	618	912	finally
    //   913	915	912	finally
  }
  
  public void enqueueAction(OpGenerator paramOpGenerator, boolean paramBoolean) {
    // Byte code:
    //   0: iload_2
    //   1: ifne -> 8
    //   4: aload_0
    //   5: invokespecial checkStateLoss : ()V
    //   8: aload_0
    //   9: monitorenter
    //   10: aload_0
    //   11: getfield mDestroyed : Z
    //   14: ifne -> 61
    //   17: aload_0
    //   18: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   21: ifnonnull -> 27
    //   24: goto -> 61
    //   27: aload_0
    //   28: getfield mPendingActions : Ljava/util/ArrayList;
    //   31: ifnonnull -> 45
    //   34: aload_0
    //   35: new java/util/ArrayList
    //   38: dup
    //   39: invokespecial <init> : ()V
    //   42: putfield mPendingActions : Ljava/util/ArrayList;
    //   45: aload_0
    //   46: getfield mPendingActions : Ljava/util/ArrayList;
    //   49: aload_1
    //   50: invokevirtual add : (Ljava/lang/Object;)Z
    //   53: pop
    //   54: aload_0
    //   55: invokevirtual scheduleCommit : ()V
    //   58: aload_0
    //   59: monitorexit
    //   60: return
    //   61: iload_2
    //   62: ifeq -> 68
    //   65: aload_0
    //   66: monitorexit
    //   67: return
    //   68: new java/lang/IllegalStateException
    //   71: dup
    //   72: ldc_w 'Activity has been destroyed'
    //   75: invokespecial <init> : (Ljava/lang/String;)V
    //   78: athrow
    //   79: astore_1
    //   80: aload_0
    //   81: monitorexit
    //   82: aload_1
    //   83: athrow
    // Exception table:
    //   from	to	target	type
    //   10	24	79	finally
    //   27	45	79	finally
    //   45	60	79	finally
    //   65	67	79	finally
    //   68	79	79	finally
    //   80	82	79	finally
  }
  
  void ensureInflatedFragmentView(Fragment paramFragment) {
    if (paramFragment.mFromLayout && !paramFragment.mPerformedCreateView) {
      paramFragment.performCreateView(paramFragment.performGetLayoutInflater(paramFragment.mSavedFragmentState), null, paramFragment.mSavedFragmentState);
      if (paramFragment.mView != null) {
        paramFragment.mInnerView = paramFragment.mView;
        paramFragment.mView.setSaveFromParentEnabled(false);
        if (paramFragment.mHidden)
          paramFragment.mView.setVisibility(8); 
        paramFragment.onViewCreated(paramFragment.mView, paramFragment.mSavedFragmentState);
        dispatchOnFragmentViewCreated(paramFragment, paramFragment.mView, paramFragment.mSavedFragmentState, false);
        return;
      } 
      paramFragment.mInnerView = null;
    } 
  }
  
  public boolean execPendingActions() {
    ensureExecReady(true);
    boolean bool = false;
    while (generateOpsForPendingActions(this.mTmpRecords, this.mTmpIsPop)) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
        cleanupExec();
      } finally {
        cleanupExec();
      } 
    } 
    doPendingDeferredStart();
    burpActive();
    return bool;
  }
  
  public void execSingleAction(OpGenerator paramOpGenerator, boolean paramBoolean) {
    if (paramBoolean && (this.mHost == null || this.mDestroyed))
      return; 
    ensureExecReady(paramBoolean);
    if (paramOpGenerator.generateOps(this.mTmpRecords, this.mTmpIsPop)) {
      this.mExecutingActions = true;
      try {
        removeRedundantOperationsAndExecute(this.mTmpRecords, this.mTmpIsPop);
      } finally {
        cleanupExec();
      } 
    } 
    doPendingDeferredStart();
    burpActive();
  }
  
  public boolean executePendingTransactions() {
    boolean bool = execPendingActions();
    forcePostponedTransactions();
    return bool;
  }
  
  public Fragment findFragmentById(int paramInt) {
    int i;
    for (i = this.mAdded.size() - 1; i >= 0; i--) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null && fragment.mFragmentId == paramInt)
        return fragment; 
    } 
    SparseArray<Fragment> sparseArray = this.mActive;
    if (sparseArray != null)
      for (i = sparseArray.size() - 1; i >= 0; i--) {
        Fragment fragment = (Fragment)this.mActive.valueAt(i);
        if (fragment != null && fragment.mFragmentId == paramInt)
          return fragment; 
      }  
    return null;
  }
  
  public Fragment findFragmentByTag(String paramString) {
    if (paramString != null)
      for (int i = this.mAdded.size() - 1; i >= 0; i--) {
        Fragment fragment = this.mAdded.get(i);
        if (fragment != null && paramString.equals(fragment.mTag))
          return fragment; 
      }  
    SparseArray<Fragment> sparseArray = this.mActive;
    if (sparseArray != null && paramString != null)
      for (int i = sparseArray.size() - 1; i >= 0; i--) {
        Fragment fragment = (Fragment)this.mActive.valueAt(i);
        if (fragment != null && paramString.equals(fragment.mTag))
          return fragment; 
      }  
    return null;
  }
  
  public Fragment findFragmentByWho(String paramString) {
    SparseArray<Fragment> sparseArray = this.mActive;
    if (sparseArray != null && paramString != null)
      for (int i = sparseArray.size() - 1; i >= 0; i--) {
        Fragment fragment = (Fragment)this.mActive.valueAt(i);
        if (fragment != null) {
          fragment = fragment.findFragmentByWho(paramString);
          if (fragment != null)
            return fragment; 
        } 
      }  
    return null;
  }
  
  public void freeBackStackIndex(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   6: iload_1
    //   7: aconst_null
    //   8: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   11: pop
    //   12: aload_0
    //   13: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   16: ifnonnull -> 30
    //   19: aload_0
    //   20: new java/util/ArrayList
    //   23: dup
    //   24: invokespecial <init> : ()V
    //   27: putfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   30: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   33: ifeq -> 68
    //   36: new java/lang/StringBuilder
    //   39: dup
    //   40: invokespecial <init> : ()V
    //   43: astore_2
    //   44: aload_2
    //   45: ldc_w 'Freeing back stack index '
    //   48: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   51: pop
    //   52: aload_2
    //   53: iload_1
    //   54: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   57: pop
    //   58: ldc 'FragmentManager'
    //   60: aload_2
    //   61: invokevirtual toString : ()Ljava/lang/String;
    //   64: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   67: pop
    //   68: aload_0
    //   69: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   72: iload_1
    //   73: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   76: invokevirtual add : (Ljava/lang/Object;)Z
    //   79: pop
    //   80: aload_0
    //   81: monitorexit
    //   82: return
    //   83: astore_2
    //   84: aload_0
    //   85: monitorexit
    //   86: aload_2
    //   87: athrow
    // Exception table:
    //   from	to	target	type
    //   2	30	83	finally
    //   30	68	83	finally
    //   68	82	83	finally
    //   84	86	83	finally
  }
  
  int getActiveFragmentCount() {
    SparseArray<Fragment> sparseArray = this.mActive;
    return (sparseArray == null) ? 0 : sparseArray.size();
  }
  
  List<Fragment> getActiveFragments() {
    SparseArray<Fragment> sparseArray = this.mActive;
    if (sparseArray == null)
      return null; 
    int j = sparseArray.size();
    ArrayList<Object> arrayList = new ArrayList(j);
    for (int i = 0; i < j; i++)
      arrayList.add(this.mActive.valueAt(i)); 
    return arrayList;
  }
  
  public FragmentManager.BackStackEntry getBackStackEntryAt(int paramInt) {
    return this.mBackStack.get(paramInt);
  }
  
  public int getBackStackEntryCount() {
    ArrayList<BackStackRecord> arrayList = this.mBackStack;
    return (arrayList != null) ? arrayList.size() : 0;
  }
  
  public Fragment getFragment(Bundle paramBundle, String paramString) {
    int i = paramBundle.getInt(paramString, -1);
    if (i == -1)
      return null; 
    Fragment fragment = (Fragment)this.mActive.get(i);
    if (fragment == null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment no longer exists for key ");
      stringBuilder.append(paramString);
      stringBuilder.append(": index ");
      stringBuilder.append(i);
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    return fragment;
  }
  
  public List<Fragment> getFragments() {
    if (this.mAdded.isEmpty())
      return Collections.emptyList(); 
    synchronized (this.mAdded) {
      return (List)this.mAdded.clone();
    } 
  }
  
  LayoutInflater.Factory2 getLayoutInflaterFactory() {
    return this;
  }
  
  public Fragment getPrimaryNavigationFragment() {
    return this.mPrimaryNav;
  }
  
  public void hideFragment(Fragment paramFragment) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("hide: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mHidden) {
      paramFragment.mHidden = true;
      paramFragment.mHiddenChanged = true ^ paramFragment.mHiddenChanged;
    } 
  }
  
  public boolean isDestroyed() {
    return this.mDestroyed;
  }
  
  boolean isStateAtLeast(int paramInt) {
    return (this.mCurState >= paramInt);
  }
  
  public boolean isStateSaved() {
    return (this.mStateSaved || this.mStopped);
  }
  
  AnimationOrAnimator loadAnimation(Fragment paramFragment, int paramInt1, boolean paramBoolean, int paramInt2) {
    int i = paramFragment.getNextAnim();
    Animation animation = paramFragment.onCreateAnimation(paramInt1, paramBoolean, i);
    if (animation != null)
      return new AnimationOrAnimator(animation); 
    Animator animator = paramFragment.onCreateAnimator(paramInt1, paramBoolean, i);
    if (animator != null)
      return new AnimationOrAnimator(animator); 
    if (i != 0) {
      boolean bool = "anim".equals(this.mHost.getContext().getResources().getResourceTypeName(i));
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool)
        try {
          Animation animation1 = AnimationUtils.loadAnimation(this.mHost.getContext(), i);
          if (animation1 != null)
            return new AnimationOrAnimator(animation1); 
          bool1 = true;
        } catch (android.content.res.Resources.NotFoundException notFoundException) {
          throw notFoundException;
        } catch (RuntimeException runtimeException) {
          bool1 = bool2;
        }  
      if (!bool1)
        try {
          animator = AnimatorInflater.loadAnimator(this.mHost.getContext(), i);
          if (animator != null)
            return new AnimationOrAnimator(animator); 
        } catch (RuntimeException runtimeException) {
          Animation animation1;
          if (!bool) {
            animation1 = AnimationUtils.loadAnimation(this.mHost.getContext(), i);
            if (animation1 != null)
              return new AnimationOrAnimator(animation1); 
          } else {
            throw animation1;
          } 
        }  
    } 
    if (paramInt1 == 0)
      return null; 
    paramInt1 = transitToStyleIndex(paramInt1, paramBoolean);
    if (paramInt1 < 0)
      return null; 
    switch (paramInt1) {
      default:
        paramInt1 = paramInt2;
        if (paramInt2 == 0) {
          paramInt1 = paramInt2;
          if (this.mHost.onHasWindowAnimations())
            paramInt1 = this.mHost.onGetWindowAnimations(); 
        } 
        break;
      case 6:
        return makeFadeAnimation(this.mHost.getContext(), 1.0F, 0.0F);
      case 5:
        return makeFadeAnimation(this.mHost.getContext(), 0.0F, 1.0F);
      case 4:
        return makeOpenCloseAnimation(this.mHost.getContext(), 1.0F, 1.075F, 1.0F, 0.0F);
      case 3:
        return makeOpenCloseAnimation(this.mHost.getContext(), 0.975F, 1.0F, 0.0F, 1.0F);
      case 2:
        return makeOpenCloseAnimation(this.mHost.getContext(), 1.0F, 0.975F, 1.0F, 0.0F);
      case 1:
        return makeOpenCloseAnimation(this.mHost.getContext(), 1.125F, 1.0F, 0.0F, 1.0F);
    } 
    if (paramInt1 == 0);
    return null;
  }
  
  void makeActive(Fragment paramFragment) {
    if (paramFragment.mIndex >= 0)
      return; 
    int i = this.mNextFragmentIndex;
    this.mNextFragmentIndex = i + 1;
    paramFragment.setIndex(i, this.mParent);
    if (this.mActive == null)
      this.mActive = new SparseArray(); 
    this.mActive.put(paramFragment.mIndex, paramFragment);
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Allocated fragment index ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  void makeInactive(Fragment paramFragment) {
    if (paramFragment.mIndex < 0)
      return; 
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Freeing fragment index ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    this.mActive.put(paramFragment.mIndex, null);
    paramFragment.initState();
  }
  
  void moveFragmentToExpectedState(Fragment paramFragment) {
    if (paramFragment == null)
      return; 
    int j = this.mCurState;
    int i = j;
    if (paramFragment.mRemoving)
      if (paramFragment.isInBackStack()) {
        i = Math.min(j, 1);
      } else {
        i = Math.min(j, 0);
      }  
    moveToState(paramFragment, i, paramFragment.getNextTransition(), paramFragment.getNextTransitionStyle(), false);
    if (paramFragment.mView != null) {
      Fragment fragment = findFragmentUnder(paramFragment);
      if (fragment != null) {
        View view = fragment.mView;
        ViewGroup viewGroup = paramFragment.mContainer;
        i = viewGroup.indexOfChild(view);
        j = viewGroup.indexOfChild(paramFragment.mView);
        if (j < i) {
          viewGroup.removeViewAt(j);
          viewGroup.addView(paramFragment.mView, i);
        } 
      } 
      if (paramFragment.mIsNewlyAdded && paramFragment.mContainer != null) {
        if (paramFragment.mPostponedAlpha > 0.0F)
          paramFragment.mView.setAlpha(paramFragment.mPostponedAlpha); 
        paramFragment.mPostponedAlpha = 0.0F;
        paramFragment.mIsNewlyAdded = false;
        AnimationOrAnimator animationOrAnimator = loadAnimation(paramFragment, paramFragment.getNextTransition(), true, paramFragment.getNextTransitionStyle());
        if (animationOrAnimator != null) {
          setHWLayerAnimListenerIfAlpha(paramFragment.mView, animationOrAnimator);
          if (animationOrAnimator.animation != null) {
            paramFragment.mView.startAnimation(animationOrAnimator.animation);
          } else {
            animationOrAnimator.animator.setTarget(paramFragment.mView);
            animationOrAnimator.animator.start();
          } 
        } 
      } 
    } 
    if (paramFragment.mHiddenChanged)
      completeShowHideFragment(paramFragment); 
  }
  
  void moveToState(int paramInt, boolean paramBoolean) {
    if (this.mHost != null || paramInt == 0) {
      if (!paramBoolean && paramInt == this.mCurState)
        return; 
      this.mCurState = paramInt;
      if (this.mActive != null) {
        int i = this.mAdded.size();
        for (paramInt = 0; paramInt < i; paramInt++)
          moveFragmentToExpectedState(this.mAdded.get(paramInt)); 
        i = this.mActive.size();
        for (paramInt = 0; paramInt < i; paramInt++) {
          Fragment fragment = (Fragment)this.mActive.valueAt(paramInt);
          if (fragment != null && (fragment.mRemoving || fragment.mDetached) && !fragment.mIsNewlyAdded)
            moveFragmentToExpectedState(fragment); 
        } 
        startPendingDeferredFragments();
        if (this.mNeedMenuInvalidate) {
          FragmentHostCallback fragmentHostCallback = this.mHost;
          if (fragmentHostCallback != null && this.mCurState == 4) {
            fragmentHostCallback.onSupportInvalidateOptionsMenu();
            this.mNeedMenuInvalidate = false;
          } 
        } 
      } 
      return;
    } 
    throw new IllegalStateException("No activity");
  }
  
  void moveToState(Fragment paramFragment) {
    moveToState(paramFragment, this.mCurState, 0, 0, false);
  }
  
  void moveToState(Fragment paramFragment, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: getfield mAdded : Z
    //   4: istore #9
    //   6: iconst_1
    //   7: istore #7
    //   9: iconst_1
    //   10: istore #8
    //   12: iload #9
    //   14: ifeq -> 30
    //   17: aload_1
    //   18: getfield mDetached : Z
    //   21: ifeq -> 27
    //   24: goto -> 30
    //   27: goto -> 44
    //   30: iload_2
    //   31: istore #6
    //   33: iload #6
    //   35: istore_2
    //   36: iload #6
    //   38: iconst_1
    //   39: if_icmple -> 44
    //   42: iconst_1
    //   43: istore_2
    //   44: iload_2
    //   45: istore #6
    //   47: aload_1
    //   48: getfield mRemoving : Z
    //   51: ifeq -> 91
    //   54: iload_2
    //   55: istore #6
    //   57: iload_2
    //   58: aload_1
    //   59: getfield mState : I
    //   62: if_icmple -> 91
    //   65: aload_1
    //   66: getfield mState : I
    //   69: ifne -> 85
    //   72: aload_1
    //   73: invokevirtual isInBackStack : ()Z
    //   76: ifeq -> 85
    //   79: iconst_1
    //   80: istore #6
    //   82: goto -> 91
    //   85: aload_1
    //   86: getfield mState : I
    //   89: istore #6
    //   91: aload_1
    //   92: getfield mDeferStart : Z
    //   95: ifeq -> 117
    //   98: aload_1
    //   99: getfield mState : I
    //   102: iconst_3
    //   103: if_icmpge -> 117
    //   106: iload #6
    //   108: iconst_2
    //   109: if_icmple -> 117
    //   112: iconst_2
    //   113: istore_2
    //   114: goto -> 120
    //   117: iload #6
    //   119: istore_2
    //   120: aload_1
    //   121: getfield mState : I
    //   124: iload_2
    //   125: if_icmpgt -> 1367
    //   128: aload_1
    //   129: getfield mFromLayout : Z
    //   132: ifeq -> 143
    //   135: aload_1
    //   136: getfield mInLayout : Z
    //   139: ifne -> 143
    //   142: return
    //   143: aload_1
    //   144: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   147: ifnonnull -> 157
    //   150: aload_1
    //   151: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   154: ifnull -> 179
    //   157: aload_1
    //   158: aconst_null
    //   159: invokevirtual setAnimatingAway : (Landroid/view/View;)V
    //   162: aload_1
    //   163: aconst_null
    //   164: invokevirtual setAnimator : (Landroid/animation/Animator;)V
    //   167: aload_0
    //   168: aload_1
    //   169: aload_1
    //   170: invokevirtual getStateAfterAnimating : ()I
    //   173: iconst_0
    //   174: iconst_0
    //   175: iconst_1
    //   176: invokevirtual moveToState : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   179: aload_1
    //   180: getfield mState : I
    //   183: istore #6
    //   185: iload #6
    //   187: ifeq -> 222
    //   190: iload_2
    //   191: istore #4
    //   193: iload #6
    //   195: iconst_1
    //   196: if_icmpeq -> 765
    //   199: iload_2
    //   200: istore_3
    //   201: iload #6
    //   203: iconst_2
    //   204: if_icmpeq -> 1225
    //   207: iload_2
    //   208: istore #4
    //   210: iload #6
    //   212: iconst_3
    //   213: if_icmpeq -> 1288
    //   216: iload_2
    //   217: istore #6
    //   219: goto -> 1976
    //   222: iload_2
    //   223: istore #4
    //   225: iload_2
    //   226: ifle -> 765
    //   229: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   232: ifeq -> 271
    //   235: new java/lang/StringBuilder
    //   238: dup
    //   239: invokespecial <init> : ()V
    //   242: astore #10
    //   244: aload #10
    //   246: ldc_w 'moveto CREATED: '
    //   249: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   252: pop
    //   253: aload #10
    //   255: aload_1
    //   256: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   259: pop
    //   260: ldc 'FragmentManager'
    //   262: aload #10
    //   264: invokevirtual toString : ()Ljava/lang/String;
    //   267: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   270: pop
    //   271: iload_2
    //   272: istore #4
    //   274: aload_1
    //   275: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   278: ifnull -> 412
    //   281: aload_1
    //   282: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   285: aload_0
    //   286: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   289: invokevirtual getContext : ()Landroid/content/Context;
    //   292: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   295: invokevirtual setClassLoader : (Ljava/lang/ClassLoader;)V
    //   298: aload_1
    //   299: aload_1
    //   300: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   303: ldc 'android:view_state'
    //   305: invokevirtual getSparseParcelableArray : (Ljava/lang/String;)Landroid/util/SparseArray;
    //   308: putfield mSavedViewState : Landroid/util/SparseArray;
    //   311: aload_1
    //   312: aload_0
    //   313: aload_1
    //   314: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   317: ldc 'android:target_state'
    //   319: invokevirtual getFragment : (Landroid/os/Bundle;Ljava/lang/String;)Landroidx/fragment/app/Fragment;
    //   322: putfield mTarget : Landroidx/fragment/app/Fragment;
    //   325: aload_1
    //   326: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   329: ifnull -> 346
    //   332: aload_1
    //   333: aload_1
    //   334: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   337: ldc 'android:target_req_state'
    //   339: iconst_0
    //   340: invokevirtual getInt : (Ljava/lang/String;I)I
    //   343: putfield mTargetRequestCode : I
    //   346: aload_1
    //   347: getfield mSavedUserVisibleHint : Ljava/lang/Boolean;
    //   350: ifnull -> 372
    //   353: aload_1
    //   354: aload_1
    //   355: getfield mSavedUserVisibleHint : Ljava/lang/Boolean;
    //   358: invokevirtual booleanValue : ()Z
    //   361: putfield mUserVisibleHint : Z
    //   364: aload_1
    //   365: aconst_null
    //   366: putfield mSavedUserVisibleHint : Ljava/lang/Boolean;
    //   369: goto -> 386
    //   372: aload_1
    //   373: aload_1
    //   374: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   377: ldc 'android:user_visible_hint'
    //   379: iconst_1
    //   380: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   383: putfield mUserVisibleHint : Z
    //   386: iload_2
    //   387: istore #4
    //   389: aload_1
    //   390: getfield mUserVisibleHint : Z
    //   393: ifne -> 412
    //   396: aload_1
    //   397: iconst_1
    //   398: putfield mDeferStart : Z
    //   401: iload_2
    //   402: istore #4
    //   404: iload_2
    //   405: iconst_2
    //   406: if_icmple -> 412
    //   409: iconst_2
    //   410: istore #4
    //   412: aload_1
    //   413: aload_0
    //   414: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   417: putfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   420: aload_1
    //   421: aload_0
    //   422: getfield mParent : Landroidx/fragment/app/Fragment;
    //   425: putfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   428: aload_0
    //   429: getfield mParent : Landroidx/fragment/app/Fragment;
    //   432: astore #10
    //   434: aload #10
    //   436: ifnull -> 449
    //   439: aload #10
    //   441: getfield mChildFragmentManager : Landroidx/fragment/app/FragmentManagerImpl;
    //   444: astore #10
    //   446: goto -> 458
    //   449: aload_0
    //   450: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   453: invokevirtual getFragmentManagerImpl : ()Landroidx/fragment/app/FragmentManagerImpl;
    //   456: astore #10
    //   458: aload_1
    //   459: aload #10
    //   461: putfield mFragmentManager : Landroidx/fragment/app/FragmentManagerImpl;
    //   464: aload_1
    //   465: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   468: ifnull -> 584
    //   471: aload_0
    //   472: getfield mActive : Landroid/util/SparseArray;
    //   475: aload_1
    //   476: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   479: getfield mIndex : I
    //   482: invokevirtual get : (I)Ljava/lang/Object;
    //   485: aload_1
    //   486: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   489: if_acmpne -> 518
    //   492: aload_1
    //   493: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   496: getfield mState : I
    //   499: iconst_1
    //   500: if_icmpge -> 584
    //   503: aload_0
    //   504: aload_1
    //   505: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   508: iconst_1
    //   509: iconst_0
    //   510: iconst_0
    //   511: iconst_1
    //   512: invokevirtual moveToState : (Landroidx/fragment/app/Fragment;IIIZ)V
    //   515: goto -> 584
    //   518: new java/lang/StringBuilder
    //   521: dup
    //   522: invokespecial <init> : ()V
    //   525: astore #10
    //   527: aload #10
    //   529: ldc_w 'Fragment '
    //   532: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   535: pop
    //   536: aload #10
    //   538: aload_1
    //   539: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   542: pop
    //   543: aload #10
    //   545: ldc_w ' declared target fragment '
    //   548: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   551: pop
    //   552: aload #10
    //   554: aload_1
    //   555: getfield mTarget : Landroidx/fragment/app/Fragment;
    //   558: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   561: pop
    //   562: aload #10
    //   564: ldc_w ' that does not belong to this FragmentManager!'
    //   567: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   570: pop
    //   571: new java/lang/IllegalStateException
    //   574: dup
    //   575: aload #10
    //   577: invokevirtual toString : ()Ljava/lang/String;
    //   580: invokespecial <init> : (Ljava/lang/String;)V
    //   583: athrow
    //   584: aload_0
    //   585: aload_1
    //   586: aload_0
    //   587: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   590: invokevirtual getContext : ()Landroid/content/Context;
    //   593: iconst_0
    //   594: invokevirtual dispatchOnFragmentPreAttached : (Landroidx/fragment/app/Fragment;Landroid/content/Context;Z)V
    //   597: aload_1
    //   598: iconst_0
    //   599: putfield mCalled : Z
    //   602: aload_1
    //   603: aload_0
    //   604: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   607: invokevirtual getContext : ()Landroid/content/Context;
    //   610: invokevirtual onAttach : (Landroid/content/Context;)V
    //   613: aload_1
    //   614: getfield mCalled : Z
    //   617: ifeq -> 718
    //   620: aload_1
    //   621: getfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   624: ifnonnull -> 638
    //   627: aload_0
    //   628: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   631: aload_1
    //   632: invokevirtual onAttachFragment : (Landroidx/fragment/app/Fragment;)V
    //   635: goto -> 646
    //   638: aload_1
    //   639: getfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   642: aload_1
    //   643: invokevirtual onAttachFragment : (Landroidx/fragment/app/Fragment;)V
    //   646: aload_0
    //   647: aload_1
    //   648: aload_0
    //   649: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   652: invokevirtual getContext : ()Landroid/content/Context;
    //   655: iconst_0
    //   656: invokevirtual dispatchOnFragmentAttached : (Landroidx/fragment/app/Fragment;Landroid/content/Context;Z)V
    //   659: aload_1
    //   660: getfield mIsCreated : Z
    //   663: ifne -> 697
    //   666: aload_0
    //   667: aload_1
    //   668: aload_1
    //   669: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   672: iconst_0
    //   673: invokevirtual dispatchOnFragmentPreCreated : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   676: aload_1
    //   677: aload_1
    //   678: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   681: invokevirtual performCreate : (Landroid/os/Bundle;)V
    //   684: aload_0
    //   685: aload_1
    //   686: aload_1
    //   687: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   690: iconst_0
    //   691: invokevirtual dispatchOnFragmentCreated : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   694: goto -> 710
    //   697: aload_1
    //   698: aload_1
    //   699: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   702: invokevirtual restoreChildFragmentState : (Landroid/os/Bundle;)V
    //   705: aload_1
    //   706: iconst_1
    //   707: putfield mState : I
    //   710: aload_1
    //   711: iconst_0
    //   712: putfield mRetaining : Z
    //   715: goto -> 765
    //   718: new java/lang/StringBuilder
    //   721: dup
    //   722: invokespecial <init> : ()V
    //   725: astore #10
    //   727: aload #10
    //   729: ldc_w 'Fragment '
    //   732: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   735: pop
    //   736: aload #10
    //   738: aload_1
    //   739: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   742: pop
    //   743: aload #10
    //   745: ldc_w ' did not call through to super.onAttach()'
    //   748: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   751: pop
    //   752: new androidx/fragment/app/SuperNotCalledException
    //   755: dup
    //   756: aload #10
    //   758: invokevirtual toString : ()Ljava/lang/String;
    //   761: invokespecial <init> : (Ljava/lang/String;)V
    //   764: athrow
    //   765: aload_0
    //   766: aload_1
    //   767: invokevirtual ensureInflatedFragmentView : (Landroidx/fragment/app/Fragment;)V
    //   770: iload #4
    //   772: istore_3
    //   773: iload #4
    //   775: iconst_1
    //   776: if_icmple -> 1225
    //   779: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   782: ifeq -> 821
    //   785: new java/lang/StringBuilder
    //   788: dup
    //   789: invokespecial <init> : ()V
    //   792: astore #10
    //   794: aload #10
    //   796: ldc_w 'moveto ACTIVITY_CREATED: '
    //   799: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   802: pop
    //   803: aload #10
    //   805: aload_1
    //   806: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   809: pop
    //   810: ldc 'FragmentManager'
    //   812: aload #10
    //   814: invokevirtual toString : ()Ljava/lang/String;
    //   817: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   820: pop
    //   821: aload_1
    //   822: getfield mFromLayout : Z
    //   825: ifne -> 1184
    //   828: aload_1
    //   829: getfield mContainerId : I
    //   832: ifeq -> 1037
    //   835: aload_1
    //   836: getfield mContainerId : I
    //   839: iconst_m1
    //   840: if_icmpne -> 893
    //   843: new java/lang/StringBuilder
    //   846: dup
    //   847: invokespecial <init> : ()V
    //   850: astore #10
    //   852: aload #10
    //   854: ldc_w 'Cannot create fragment '
    //   857: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   860: pop
    //   861: aload #10
    //   863: aload_1
    //   864: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   867: pop
    //   868: aload #10
    //   870: ldc_w ' for a container view with no id'
    //   873: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   876: pop
    //   877: aload_0
    //   878: new java/lang/IllegalArgumentException
    //   881: dup
    //   882: aload #10
    //   884: invokevirtual toString : ()Ljava/lang/String;
    //   887: invokespecial <init> : (Ljava/lang/String;)V
    //   890: invokespecial throwException : (Ljava/lang/RuntimeException;)V
    //   893: aload_0
    //   894: getfield mContainer : Landroidx/fragment/app/FragmentContainer;
    //   897: aload_1
    //   898: getfield mContainerId : I
    //   901: invokevirtual onFindViewById : (I)Landroid/view/View;
    //   904: checkcast android/view/ViewGroup
    //   907: astore #11
    //   909: aload #11
    //   911: astore #10
    //   913: aload #11
    //   915: ifnonnull -> 1040
    //   918: aload #11
    //   920: astore #10
    //   922: aload_1
    //   923: getfield mRestored : Z
    //   926: ifne -> 1040
    //   929: aload_1
    //   930: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   933: aload_1
    //   934: getfield mContainerId : I
    //   937: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   940: astore #10
    //   942: goto -> 950
    //   945: ldc_w 'unknown'
    //   948: astore #10
    //   950: new java/lang/StringBuilder
    //   953: dup
    //   954: invokespecial <init> : ()V
    //   957: astore #12
    //   959: aload #12
    //   961: ldc_w 'No view found for id 0x'
    //   964: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   967: pop
    //   968: aload #12
    //   970: aload_1
    //   971: getfield mContainerId : I
    //   974: invokestatic toHexString : (I)Ljava/lang/String;
    //   977: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   980: pop
    //   981: aload #12
    //   983: ldc_w ' ('
    //   986: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   989: pop
    //   990: aload #12
    //   992: aload #10
    //   994: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   997: pop
    //   998: aload #12
    //   1000: ldc_w ') for fragment '
    //   1003: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1006: pop
    //   1007: aload #12
    //   1009: aload_1
    //   1010: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1013: pop
    //   1014: aload_0
    //   1015: new java/lang/IllegalArgumentException
    //   1018: dup
    //   1019: aload #12
    //   1021: invokevirtual toString : ()Ljava/lang/String;
    //   1024: invokespecial <init> : (Ljava/lang/String;)V
    //   1027: invokespecial throwException : (Ljava/lang/RuntimeException;)V
    //   1030: aload #11
    //   1032: astore #10
    //   1034: goto -> 1040
    //   1037: aconst_null
    //   1038: astore #10
    //   1040: aload_1
    //   1041: aload #10
    //   1043: putfield mContainer : Landroid/view/ViewGroup;
    //   1046: aload_1
    //   1047: aload_1
    //   1048: aload_1
    //   1049: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1052: invokevirtual performGetLayoutInflater : (Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    //   1055: aload #10
    //   1057: aload_1
    //   1058: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1061: invokevirtual performCreateView : (Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V
    //   1064: aload_1
    //   1065: getfield mView : Landroid/view/View;
    //   1068: ifnull -> 1179
    //   1071: aload_1
    //   1072: aload_1
    //   1073: getfield mView : Landroid/view/View;
    //   1076: putfield mInnerView : Landroid/view/View;
    //   1079: aload_1
    //   1080: getfield mView : Landroid/view/View;
    //   1083: iconst_0
    //   1084: invokevirtual setSaveFromParentEnabled : (Z)V
    //   1087: aload #10
    //   1089: ifnull -> 1101
    //   1092: aload #10
    //   1094: aload_1
    //   1095: getfield mView : Landroid/view/View;
    //   1098: invokevirtual addView : (Landroid/view/View;)V
    //   1101: aload_1
    //   1102: getfield mHidden : Z
    //   1105: ifeq -> 1117
    //   1108: aload_1
    //   1109: getfield mView : Landroid/view/View;
    //   1112: bipush #8
    //   1114: invokevirtual setVisibility : (I)V
    //   1117: aload_1
    //   1118: aload_1
    //   1119: getfield mView : Landroid/view/View;
    //   1122: aload_1
    //   1123: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1126: invokevirtual onViewCreated : (Landroid/view/View;Landroid/os/Bundle;)V
    //   1129: aload_0
    //   1130: aload_1
    //   1131: aload_1
    //   1132: getfield mView : Landroid/view/View;
    //   1135: aload_1
    //   1136: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1139: iconst_0
    //   1140: invokevirtual dispatchOnFragmentViewCreated : (Landroidx/fragment/app/Fragment;Landroid/view/View;Landroid/os/Bundle;Z)V
    //   1143: aload_1
    //   1144: getfield mView : Landroid/view/View;
    //   1147: invokevirtual getVisibility : ()I
    //   1150: ifne -> 1167
    //   1153: aload_1
    //   1154: getfield mContainer : Landroid/view/ViewGroup;
    //   1157: ifnull -> 1167
    //   1160: iload #8
    //   1162: istore #5
    //   1164: goto -> 1170
    //   1167: iconst_0
    //   1168: istore #5
    //   1170: aload_1
    //   1171: iload #5
    //   1173: putfield mIsNewlyAdded : Z
    //   1176: goto -> 1184
    //   1179: aload_1
    //   1180: aconst_null
    //   1181: putfield mInnerView : Landroid/view/View;
    //   1184: aload_1
    //   1185: aload_1
    //   1186: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1189: invokevirtual performActivityCreated : (Landroid/os/Bundle;)V
    //   1192: aload_0
    //   1193: aload_1
    //   1194: aload_1
    //   1195: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1198: iconst_0
    //   1199: invokevirtual dispatchOnFragmentActivityCreated : (Landroidx/fragment/app/Fragment;Landroid/os/Bundle;Z)V
    //   1202: aload_1
    //   1203: getfield mView : Landroid/view/View;
    //   1206: ifnull -> 1217
    //   1209: aload_1
    //   1210: aload_1
    //   1211: getfield mSavedFragmentState : Landroid/os/Bundle;
    //   1214: invokevirtual restoreViewState : (Landroid/os/Bundle;)V
    //   1217: aload_1
    //   1218: aconst_null
    //   1219: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   1222: iload #4
    //   1224: istore_3
    //   1225: iload_3
    //   1226: istore #4
    //   1228: iload_3
    //   1229: iconst_2
    //   1230: if_icmple -> 1288
    //   1233: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1236: ifeq -> 1275
    //   1239: new java/lang/StringBuilder
    //   1242: dup
    //   1243: invokespecial <init> : ()V
    //   1246: astore #10
    //   1248: aload #10
    //   1250: ldc_w 'moveto STARTED: '
    //   1253: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1256: pop
    //   1257: aload #10
    //   1259: aload_1
    //   1260: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1263: pop
    //   1264: ldc 'FragmentManager'
    //   1266: aload #10
    //   1268: invokevirtual toString : ()Ljava/lang/String;
    //   1271: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1274: pop
    //   1275: aload_1
    //   1276: invokevirtual performStart : ()V
    //   1279: aload_0
    //   1280: aload_1
    //   1281: iconst_0
    //   1282: invokevirtual dispatchOnFragmentStarted : (Landroidx/fragment/app/Fragment;Z)V
    //   1285: iload_3
    //   1286: istore #4
    //   1288: iload #4
    //   1290: istore #6
    //   1292: iload #4
    //   1294: iconst_3
    //   1295: if_icmple -> 1976
    //   1298: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1301: ifeq -> 1340
    //   1304: new java/lang/StringBuilder
    //   1307: dup
    //   1308: invokespecial <init> : ()V
    //   1311: astore #10
    //   1313: aload #10
    //   1315: ldc_w 'moveto RESUMED: '
    //   1318: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1321: pop
    //   1322: aload #10
    //   1324: aload_1
    //   1325: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1328: pop
    //   1329: ldc 'FragmentManager'
    //   1331: aload #10
    //   1333: invokevirtual toString : ()Ljava/lang/String;
    //   1336: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1339: pop
    //   1340: aload_1
    //   1341: invokevirtual performResume : ()V
    //   1344: aload_0
    //   1345: aload_1
    //   1346: iconst_0
    //   1347: invokevirtual dispatchOnFragmentResumed : (Landroidx/fragment/app/Fragment;Z)V
    //   1350: aload_1
    //   1351: aconst_null
    //   1352: putfield mSavedFragmentState : Landroid/os/Bundle;
    //   1355: aload_1
    //   1356: aconst_null
    //   1357: putfield mSavedViewState : Landroid/util/SparseArray;
    //   1360: iload #4
    //   1362: istore #6
    //   1364: goto -> 1976
    //   1367: iload_2
    //   1368: istore #6
    //   1370: aload_1
    //   1371: getfield mState : I
    //   1374: iload_2
    //   1375: if_icmple -> 1976
    //   1378: aload_1
    //   1379: getfield mState : I
    //   1382: istore #6
    //   1384: iload #6
    //   1386: iconst_1
    //   1387: if_icmpeq -> 1759
    //   1390: iload #6
    //   1392: iconst_2
    //   1393: if_icmpeq -> 1528
    //   1396: iload #6
    //   1398: iconst_3
    //   1399: if_icmpeq -> 1471
    //   1402: iload #6
    //   1404: iconst_4
    //   1405: if_icmpeq -> 1414
    //   1408: iload_2
    //   1409: istore #6
    //   1411: goto -> 1976
    //   1414: iload_2
    //   1415: iconst_4
    //   1416: if_icmpge -> 1471
    //   1419: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1422: ifeq -> 1461
    //   1425: new java/lang/StringBuilder
    //   1428: dup
    //   1429: invokespecial <init> : ()V
    //   1432: astore #10
    //   1434: aload #10
    //   1436: ldc_w 'movefrom RESUMED: '
    //   1439: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1442: pop
    //   1443: aload #10
    //   1445: aload_1
    //   1446: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1449: pop
    //   1450: ldc 'FragmentManager'
    //   1452: aload #10
    //   1454: invokevirtual toString : ()Ljava/lang/String;
    //   1457: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1460: pop
    //   1461: aload_1
    //   1462: invokevirtual performPause : ()V
    //   1465: aload_0
    //   1466: aload_1
    //   1467: iconst_0
    //   1468: invokevirtual dispatchOnFragmentPaused : (Landroidx/fragment/app/Fragment;Z)V
    //   1471: iload_2
    //   1472: iconst_3
    //   1473: if_icmpge -> 1528
    //   1476: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1479: ifeq -> 1518
    //   1482: new java/lang/StringBuilder
    //   1485: dup
    //   1486: invokespecial <init> : ()V
    //   1489: astore #10
    //   1491: aload #10
    //   1493: ldc_w 'movefrom STARTED: '
    //   1496: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1499: pop
    //   1500: aload #10
    //   1502: aload_1
    //   1503: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1506: pop
    //   1507: ldc 'FragmentManager'
    //   1509: aload #10
    //   1511: invokevirtual toString : ()Ljava/lang/String;
    //   1514: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1517: pop
    //   1518: aload_1
    //   1519: invokevirtual performStop : ()V
    //   1522: aload_0
    //   1523: aload_1
    //   1524: iconst_0
    //   1525: invokevirtual dispatchOnFragmentStopped : (Landroidx/fragment/app/Fragment;Z)V
    //   1528: iload_2
    //   1529: iconst_2
    //   1530: if_icmpge -> 1759
    //   1533: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1536: ifeq -> 1575
    //   1539: new java/lang/StringBuilder
    //   1542: dup
    //   1543: invokespecial <init> : ()V
    //   1546: astore #10
    //   1548: aload #10
    //   1550: ldc_w 'movefrom ACTIVITY_CREATED: '
    //   1553: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1556: pop
    //   1557: aload #10
    //   1559: aload_1
    //   1560: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1563: pop
    //   1564: ldc 'FragmentManager'
    //   1566: aload #10
    //   1568: invokevirtual toString : ()Ljava/lang/String;
    //   1571: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1574: pop
    //   1575: aload_1
    //   1576: getfield mView : Landroid/view/View;
    //   1579: ifnull -> 1605
    //   1582: aload_0
    //   1583: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   1586: aload_1
    //   1587: invokevirtual onShouldSaveFragmentState : (Landroidx/fragment/app/Fragment;)Z
    //   1590: ifeq -> 1605
    //   1593: aload_1
    //   1594: getfield mSavedViewState : Landroid/util/SparseArray;
    //   1597: ifnonnull -> 1605
    //   1600: aload_0
    //   1601: aload_1
    //   1602: invokevirtual saveFragmentViewState : (Landroidx/fragment/app/Fragment;)V
    //   1605: aload_1
    //   1606: invokevirtual performDestroyView : ()V
    //   1609: aload_0
    //   1610: aload_1
    //   1611: iconst_0
    //   1612: invokevirtual dispatchOnFragmentViewDestroyed : (Landroidx/fragment/app/Fragment;Z)V
    //   1615: aload_1
    //   1616: getfield mView : Landroid/view/View;
    //   1619: ifnull -> 1726
    //   1622: aload_1
    //   1623: getfield mContainer : Landroid/view/ViewGroup;
    //   1626: ifnull -> 1726
    //   1629: aload_1
    //   1630: getfield mContainer : Landroid/view/ViewGroup;
    //   1633: aload_1
    //   1634: getfield mView : Landroid/view/View;
    //   1637: invokevirtual endViewTransition : (Landroid/view/View;)V
    //   1640: aload_1
    //   1641: getfield mView : Landroid/view/View;
    //   1644: invokevirtual clearAnimation : ()V
    //   1647: aload_0
    //   1648: getfield mCurState : I
    //   1651: ifle -> 1694
    //   1654: aload_0
    //   1655: getfield mDestroyed : Z
    //   1658: ifne -> 1694
    //   1661: aload_1
    //   1662: getfield mView : Landroid/view/View;
    //   1665: invokevirtual getVisibility : ()I
    //   1668: ifne -> 1694
    //   1671: aload_1
    //   1672: getfield mPostponedAlpha : F
    //   1675: fconst_0
    //   1676: fcmpl
    //   1677: iflt -> 1694
    //   1680: aload_0
    //   1681: aload_1
    //   1682: iload_3
    //   1683: iconst_0
    //   1684: iload #4
    //   1686: invokevirtual loadAnimation : (Landroidx/fragment/app/Fragment;IZI)Landroidx/fragment/app/FragmentManagerImpl$AnimationOrAnimator;
    //   1689: astore #10
    //   1691: goto -> 1697
    //   1694: aconst_null
    //   1695: astore #10
    //   1697: aload_1
    //   1698: fconst_0
    //   1699: putfield mPostponedAlpha : F
    //   1702: aload #10
    //   1704: ifnull -> 1715
    //   1707: aload_0
    //   1708: aload_1
    //   1709: aload #10
    //   1711: iload_2
    //   1712: invokespecial animateRemoveFragment : (Landroidx/fragment/app/Fragment;Landroidx/fragment/app/FragmentManagerImpl$AnimationOrAnimator;I)V
    //   1715: aload_1
    //   1716: getfield mContainer : Landroid/view/ViewGroup;
    //   1719: aload_1
    //   1720: getfield mView : Landroid/view/View;
    //   1723: invokevirtual removeView : (Landroid/view/View;)V
    //   1726: aload_1
    //   1727: aconst_null
    //   1728: putfield mContainer : Landroid/view/ViewGroup;
    //   1731: aload_1
    //   1732: aconst_null
    //   1733: putfield mView : Landroid/view/View;
    //   1736: aload_1
    //   1737: aconst_null
    //   1738: putfield mViewLifecycleOwner : Landroidx/lifecycle/LifecycleOwner;
    //   1741: aload_1
    //   1742: getfield mViewLifecycleOwnerLiveData : Landroidx/lifecycle/MutableLiveData;
    //   1745: aconst_null
    //   1746: invokevirtual setValue : (Ljava/lang/Object;)V
    //   1749: aload_1
    //   1750: aconst_null
    //   1751: putfield mInnerView : Landroid/view/View;
    //   1754: aload_1
    //   1755: iconst_0
    //   1756: putfield mInLayout : Z
    //   1759: iload_2
    //   1760: istore #6
    //   1762: iload_2
    //   1763: iconst_1
    //   1764: if_icmpge -> 1976
    //   1767: aload_0
    //   1768: getfield mDestroyed : Z
    //   1771: ifeq -> 1823
    //   1774: aload_1
    //   1775: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   1778: ifnull -> 1800
    //   1781: aload_1
    //   1782: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   1785: astore #10
    //   1787: aload_1
    //   1788: aconst_null
    //   1789: invokevirtual setAnimatingAway : (Landroid/view/View;)V
    //   1792: aload #10
    //   1794: invokevirtual clearAnimation : ()V
    //   1797: goto -> 1823
    //   1800: aload_1
    //   1801: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   1804: ifnull -> 1823
    //   1807: aload_1
    //   1808: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   1811: astore #10
    //   1813: aload_1
    //   1814: aconst_null
    //   1815: invokevirtual setAnimator : (Landroid/animation/Animator;)V
    //   1818: aload #10
    //   1820: invokevirtual cancel : ()V
    //   1823: aload_1
    //   1824: invokevirtual getAnimatingAway : ()Landroid/view/View;
    //   1827: ifnonnull -> 1964
    //   1830: aload_1
    //   1831: invokevirtual getAnimator : ()Landroid/animation/Animator;
    //   1834: ifnull -> 1840
    //   1837: goto -> 1964
    //   1840: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   1843: ifeq -> 1882
    //   1846: new java/lang/StringBuilder
    //   1849: dup
    //   1850: invokespecial <init> : ()V
    //   1853: astore #10
    //   1855: aload #10
    //   1857: ldc_w 'movefrom CREATED: '
    //   1860: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1863: pop
    //   1864: aload #10
    //   1866: aload_1
    //   1867: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1870: pop
    //   1871: ldc 'FragmentManager'
    //   1873: aload #10
    //   1875: invokevirtual toString : ()Ljava/lang/String;
    //   1878: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   1881: pop
    //   1882: aload_1
    //   1883: getfield mRetaining : Z
    //   1886: ifne -> 1902
    //   1889: aload_1
    //   1890: invokevirtual performDestroy : ()V
    //   1893: aload_0
    //   1894: aload_1
    //   1895: iconst_0
    //   1896: invokevirtual dispatchOnFragmentDestroyed : (Landroidx/fragment/app/Fragment;Z)V
    //   1899: goto -> 1907
    //   1902: aload_1
    //   1903: iconst_0
    //   1904: putfield mState : I
    //   1907: aload_1
    //   1908: invokevirtual performDetach : ()V
    //   1911: aload_0
    //   1912: aload_1
    //   1913: iconst_0
    //   1914: invokevirtual dispatchOnFragmentDetached : (Landroidx/fragment/app/Fragment;Z)V
    //   1917: iload_2
    //   1918: istore #6
    //   1920: iload #5
    //   1922: ifne -> 1976
    //   1925: aload_1
    //   1926: getfield mRetaining : Z
    //   1929: ifne -> 1943
    //   1932: aload_0
    //   1933: aload_1
    //   1934: invokevirtual makeInactive : (Landroidx/fragment/app/Fragment;)V
    //   1937: iload_2
    //   1938: istore #6
    //   1940: goto -> 1976
    //   1943: aload_1
    //   1944: aconst_null
    //   1945: putfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   1948: aload_1
    //   1949: aconst_null
    //   1950: putfield mParentFragment : Landroidx/fragment/app/Fragment;
    //   1953: aload_1
    //   1954: aconst_null
    //   1955: putfield mFragmentManager : Landroidx/fragment/app/FragmentManagerImpl;
    //   1958: iload_2
    //   1959: istore #6
    //   1961: goto -> 1976
    //   1964: aload_1
    //   1965: iload_2
    //   1966: invokevirtual setStateAfterAnimating : (I)V
    //   1969: iload #7
    //   1971: istore #6
    //   1973: goto -> 1976
    //   1976: aload_1
    //   1977: getfield mState : I
    //   1980: iload #6
    //   1982: if_icmpeq -> 2072
    //   1985: new java/lang/StringBuilder
    //   1988: dup
    //   1989: invokespecial <init> : ()V
    //   1992: astore #10
    //   1994: aload #10
    //   1996: ldc_w 'moveToState: Fragment state for '
    //   1999: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2002: pop
    //   2003: aload #10
    //   2005: aload_1
    //   2006: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2009: pop
    //   2010: aload #10
    //   2012: ldc_w ' not updated inline; '
    //   2015: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2018: pop
    //   2019: aload #10
    //   2021: ldc_w 'expected state '
    //   2024: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2027: pop
    //   2028: aload #10
    //   2030: iload #6
    //   2032: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2035: pop
    //   2036: aload #10
    //   2038: ldc_w ' found '
    //   2041: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2044: pop
    //   2045: aload #10
    //   2047: aload_1
    //   2048: getfield mState : I
    //   2051: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2054: pop
    //   2055: ldc 'FragmentManager'
    //   2057: aload #10
    //   2059: invokevirtual toString : ()Ljava/lang/String;
    //   2062: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   2065: pop
    //   2066: aload_1
    //   2067: iload #6
    //   2069: putfield mState : I
    //   2072: return
    //   2073: astore #10
    //   2075: goto -> 945
    // Exception table:
    //   from	to	target	type
    //   929	942	2073	android/content/res/Resources$NotFoundException
  }
  
  public void noteStateNotSaved() {
    this.mSavedNonConfig = null;
    int i = 0;
    this.mStateSaved = false;
    this.mStopped = false;
    int j = this.mAdded.size();
    while (i < j) {
      Fragment fragment = this.mAdded.get(i);
      if (fragment != null)
        fragment.noteStateNotSaved(); 
      i++;
    } 
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    if (!"fragment".equals(paramString))
      return null; 
    paramString = paramAttributeSet.getAttributeValue(null, "class");
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, FragmentTag.Fragment);
    int i = 0;
    String str1 = paramString;
    if (paramString == null)
      str1 = typedArray.getString(0); 
    int j = typedArray.getResourceId(1, -1);
    String str2 = typedArray.getString(2);
    typedArray.recycle();
    if (!Fragment.isSupportFragmentClass(this.mHost.getContext(), str1))
      return null; 
    if (paramView != null)
      i = paramView.getId(); 
    if (i != -1 || j != -1 || str2 != null) {
      Fragment fragment2;
      if (j != -1) {
        Fragment fragment = findFragmentById(j);
      } else {
        paramView = null;
      } 
      View view = paramView;
      if (paramView == null) {
        view = paramView;
        if (str2 != null)
          fragment2 = findFragmentByTag(str2); 
      } 
      Fragment fragment1 = fragment2;
      if (fragment2 == null) {
        fragment1 = fragment2;
        if (i != -1)
          fragment1 = findFragmentById(i); 
      } 
      if (DEBUG) {
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("onCreateView: id=0x");
        stringBuilder2.append(Integer.toHexString(j));
        stringBuilder2.append(" fname=");
        stringBuilder2.append(str1);
        stringBuilder2.append(" existing=");
        stringBuilder2.append(fragment1);
        Log.v("FragmentManager", stringBuilder2.toString());
      } 
      if (fragment1 == null) {
        int k;
        fragment2 = this.mContainer.instantiate(paramContext, str1, null);
        fragment2.mFromLayout = true;
        if (j != 0) {
          k = j;
        } else {
          k = i;
        } 
        fragment2.mFragmentId = k;
        fragment2.mContainerId = i;
        fragment2.mTag = str2;
        fragment2.mInLayout = true;
        fragment2.mFragmentManager = this;
        fragment2.mHost = this.mHost;
        fragment2.onInflate(this.mHost.getContext(), paramAttributeSet, fragment2.mSavedFragmentState);
        addFragment(fragment2, true);
      } else if (!fragment1.mInLayout) {
        fragment1.mInLayout = true;
        fragment1.mHost = this.mHost;
        fragment2 = fragment1;
        if (!fragment1.mRetaining) {
          fragment1.onInflate(this.mHost.getContext(), paramAttributeSet, fragment1.mSavedFragmentState);
          fragment2 = fragment1;
        } 
      } else {
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(paramAttributeSet.getPositionDescription());
        stringBuilder2.append(": Duplicate id 0x");
        stringBuilder2.append(Integer.toHexString(j));
        stringBuilder2.append(", tag ");
        stringBuilder2.append(str2);
        stringBuilder2.append(", or parent id 0x");
        stringBuilder2.append(Integer.toHexString(i));
        stringBuilder2.append(" with another fragment for ");
        stringBuilder2.append(str1);
        throw new IllegalArgumentException(stringBuilder2.toString());
      } 
      if (this.mCurState < 1 && fragment2.mFromLayout) {
        moveToState(fragment2, 1, 0, 0, false);
      } else {
        moveToState(fragment2);
      } 
      if (fragment2.mView != null) {
        if (j != 0)
          fragment2.mView.setId(j); 
        if (fragment2.mView.getTag() == null)
          fragment2.mView.setTag(str2); 
        return fragment2.mView;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Fragment ");
      stringBuilder1.append(str1);
      stringBuilder1.append(" did not create a view.");
      throw new IllegalStateException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramAttributeSet.getPositionDescription());
    stringBuilder.append(": Must specify unique android:id, android:tag, or have a parent with an id for ");
    stringBuilder.append(str1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  public void performPendingDeferredStart(Fragment paramFragment) {
    if (paramFragment.mDeferStart) {
      if (this.mExecutingActions) {
        this.mHavePendingDeferredStart = true;
        return;
      } 
      paramFragment.mDeferStart = false;
      moveToState(paramFragment, this.mCurState, 0, 0, false);
    } 
  }
  
  public void popBackStack() {
    enqueueAction(new PopBackStackState(null, -1, 0), false);
  }
  
  public void popBackStack(int paramInt1, int paramInt2) {
    if (paramInt1 >= 0) {
      enqueueAction(new PopBackStackState(null, paramInt1, paramInt2), false);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void popBackStack(String paramString, int paramInt) {
    enqueueAction(new PopBackStackState(paramString, -1, paramInt), false);
  }
  
  public boolean popBackStackImmediate() {
    checkStateLoss();
    return popBackStackImmediate(null, -1, 0);
  }
  
  public boolean popBackStackImmediate(int paramInt1, int paramInt2) {
    checkStateLoss();
    execPendingActions();
    if (paramInt1 >= 0)
      return popBackStackImmediate(null, paramInt1, paramInt2); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public boolean popBackStackImmediate(String paramString, int paramInt) {
    checkStateLoss();
    return popBackStackImmediate(paramString, -1, paramInt);
  }
  
  boolean popBackStackState(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, String paramString, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mBackStack : Ljava/util/ArrayList;
    //   4: astore #8
    //   6: aload #8
    //   8: ifnonnull -> 13
    //   11: iconst_0
    //   12: ireturn
    //   13: aload_3
    //   14: ifnonnull -> 70
    //   17: iload #4
    //   19: ifge -> 70
    //   22: iload #5
    //   24: iconst_1
    //   25: iand
    //   26: ifne -> 70
    //   29: aload #8
    //   31: invokevirtual size : ()I
    //   34: iconst_1
    //   35: isub
    //   36: istore #4
    //   38: iload #4
    //   40: ifge -> 45
    //   43: iconst_0
    //   44: ireturn
    //   45: aload_1
    //   46: aload_0
    //   47: getfield mBackStack : Ljava/util/ArrayList;
    //   50: iload #4
    //   52: invokevirtual remove : (I)Ljava/lang/Object;
    //   55: invokevirtual add : (Ljava/lang/Object;)Z
    //   58: pop
    //   59: aload_2
    //   60: iconst_1
    //   61: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   64: invokevirtual add : (Ljava/lang/Object;)Z
    //   67: pop
    //   68: iconst_1
    //   69: ireturn
    //   70: aload_3
    //   71: ifnonnull -> 88
    //   74: iload #4
    //   76: iflt -> 82
    //   79: goto -> 88
    //   82: iconst_m1
    //   83: istore #4
    //   85: goto -> 265
    //   88: aload_0
    //   89: getfield mBackStack : Ljava/util/ArrayList;
    //   92: invokevirtual size : ()I
    //   95: iconst_1
    //   96: isub
    //   97: istore #6
    //   99: iload #6
    //   101: iflt -> 164
    //   104: aload_0
    //   105: getfield mBackStack : Ljava/util/ArrayList;
    //   108: iload #6
    //   110: invokevirtual get : (I)Ljava/lang/Object;
    //   113: checkcast androidx/fragment/app/BackStackRecord
    //   116: astore #8
    //   118: aload_3
    //   119: ifnull -> 137
    //   122: aload_3
    //   123: aload #8
    //   125: invokevirtual getName : ()Ljava/lang/String;
    //   128: invokevirtual equals : (Ljava/lang/Object;)Z
    //   131: ifeq -> 137
    //   134: goto -> 164
    //   137: iload #4
    //   139: iflt -> 155
    //   142: iload #4
    //   144: aload #8
    //   146: getfield mIndex : I
    //   149: if_icmpne -> 155
    //   152: goto -> 164
    //   155: iload #6
    //   157: iconst_1
    //   158: isub
    //   159: istore #6
    //   161: goto -> 99
    //   164: iload #6
    //   166: ifge -> 171
    //   169: iconst_0
    //   170: ireturn
    //   171: iload #6
    //   173: istore #7
    //   175: iload #5
    //   177: iconst_1
    //   178: iand
    //   179: ifeq -> 261
    //   182: iload #6
    //   184: iconst_1
    //   185: isub
    //   186: istore #5
    //   188: iload #5
    //   190: istore #7
    //   192: iload #5
    //   194: iflt -> 261
    //   197: aload_0
    //   198: getfield mBackStack : Ljava/util/ArrayList;
    //   201: iload #5
    //   203: invokevirtual get : (I)Ljava/lang/Object;
    //   206: checkcast androidx/fragment/app/BackStackRecord
    //   209: astore #8
    //   211: aload_3
    //   212: ifnull -> 231
    //   215: iload #5
    //   217: istore #6
    //   219: aload_3
    //   220: aload #8
    //   222: invokevirtual getName : ()Ljava/lang/String;
    //   225: invokevirtual equals : (Ljava/lang/Object;)Z
    //   228: ifne -> 182
    //   231: iload #5
    //   233: istore #7
    //   235: iload #4
    //   237: iflt -> 261
    //   240: iload #5
    //   242: istore #7
    //   244: iload #4
    //   246: aload #8
    //   248: getfield mIndex : I
    //   251: if_icmpne -> 261
    //   254: iload #5
    //   256: istore #6
    //   258: goto -> 182
    //   261: iload #7
    //   263: istore #4
    //   265: iload #4
    //   267: aload_0
    //   268: getfield mBackStack : Ljava/util/ArrayList;
    //   271: invokevirtual size : ()I
    //   274: iconst_1
    //   275: isub
    //   276: if_icmpne -> 281
    //   279: iconst_0
    //   280: ireturn
    //   281: aload_0
    //   282: getfield mBackStack : Ljava/util/ArrayList;
    //   285: invokevirtual size : ()I
    //   288: iconst_1
    //   289: isub
    //   290: istore #5
    //   292: iload #5
    //   294: iload #4
    //   296: if_icmple -> 331
    //   299: aload_1
    //   300: aload_0
    //   301: getfield mBackStack : Ljava/util/ArrayList;
    //   304: iload #5
    //   306: invokevirtual remove : (I)Ljava/lang/Object;
    //   309: invokevirtual add : (Ljava/lang/Object;)Z
    //   312: pop
    //   313: aload_2
    //   314: iconst_1
    //   315: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   318: invokevirtual add : (Ljava/lang/Object;)Z
    //   321: pop
    //   322: iload #5
    //   324: iconst_1
    //   325: isub
    //   326: istore #5
    //   328: goto -> 292
    //   331: iconst_1
    //   332: ireturn
  }
  
  public void putFragment(Bundle paramBundle, String paramString, Fragment paramFragment) {
    if (paramFragment.mIndex < 0) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" is not currently in the FragmentManager");
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    paramBundle.putInt(paramString, paramFragment.mIndex);
  }
  
  public void registerFragmentLifecycleCallbacks(FragmentManager.FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks, boolean paramBoolean) {
    this.mLifecycleCallbacks.add(new FragmentLifecycleCallbacksHolder(paramFragmentLifecycleCallbacks, paramBoolean));
  }
  
  public void removeFragment(Fragment paramFragment) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("remove: ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" nesting=");
      stringBuilder.append(paramFragment.mBackStackNesting);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    boolean bool = paramFragment.isInBackStack();
    if (!paramFragment.mDetached || (bool ^ true) != 0)
      synchronized (this.mAdded) {
        this.mAdded.remove(paramFragment);
        if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
          this.mNeedMenuInvalidate = true; 
        paramFragment.mAdded = false;
        paramFragment.mRemoving = true;
        return;
      }  
  }
  
  public void removeOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener paramOnBackStackChangedListener) {
    ArrayList<FragmentManager.OnBackStackChangedListener> arrayList = this.mBackStackChangeListeners;
    if (arrayList != null)
      arrayList.remove(paramOnBackStackChangedListener); 
  }
  
  void reportBackStackChanged() {
    if (this.mBackStackChangeListeners != null)
      for (int i = 0; i < this.mBackStackChangeListeners.size(); i++)
        ((FragmentManager.OnBackStackChangedListener)this.mBackStackChangeListeners.get(i)).onBackStackChanged();  
  }
  
  void restoreAllState(Parcelable<FragmentManagerNonConfig> paramParcelable, FragmentManagerNonConfig paramFragmentManagerNonConfig) {
    Parcelable<FragmentManagerNonConfig> parcelable;
    if (paramParcelable == null)
      return; 
    FragmentManagerState fragmentManagerState = (FragmentManagerState)paramParcelable;
    if (fragmentManagerState.mActive == null)
      return; 
    if (paramFragmentManagerNonConfig != null) {
      byte b;
      List<Fragment> list2 = paramFragmentManagerNonConfig.getFragments();
      List<FragmentManagerNonConfig> list = paramFragmentManagerNonConfig.getChildNonConfigs();
      List<ViewModelStore> list1 = paramFragmentManagerNonConfig.getViewModelStores();
      if (list2 != null) {
        b = list2.size();
      } else {
        b = 0;
      } 
      int j = 0;
      while (true) {
        List<FragmentManagerNonConfig> list4 = list;
        List<ViewModelStore> list3 = list1;
        if (j < b) {
          Fragment fragment = list2.get(j);
          if (DEBUG) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("restoreAllState: re-attaching retained ");
            stringBuilder.append(fragment);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          int k;
          for (k = 0; k < fragmentManagerState.mActive.length && (fragmentManagerState.mActive[k]).mIndex != fragment.mIndex; k++);
          if (k == fragmentManagerState.mActive.length) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Could not find active fragment with index ");
            stringBuilder.append(fragment.mIndex);
            throwException(new IllegalStateException(stringBuilder.toString()));
          } 
          parcelable = fragmentManagerState.mActive[k];
          ((FragmentState)parcelable).mInstance = fragment;
          fragment.mSavedViewState = null;
          fragment.mBackStackNesting = 0;
          fragment.mInLayout = false;
          fragment.mAdded = false;
          fragment.mTarget = null;
          if (((FragmentState)parcelable).mSavedFragmentState != null) {
            ((FragmentState)parcelable).mSavedFragmentState.setClassLoader(this.mHost.getContext().getClassLoader());
            fragment.mSavedViewState = ((FragmentState)parcelable).mSavedFragmentState.getSparseParcelableArray("android:view_state");
            fragment.mSavedFragmentState = ((FragmentState)parcelable).mSavedFragmentState;
          } 
          j++;
          continue;
        } 
        break;
      } 
    } else {
      parcelable = null;
      paramParcelable = parcelable;
    } 
    this.mActive = new SparseArray(fragmentManagerState.mActive.length);
    int i;
    for (i = 0; i < fragmentManagerState.mActive.length; i++) {
      FragmentState fragmentState = fragmentManagerState.mActive[i];
      if (fragmentState != null) {
        ViewModelStore viewModelStore;
        if (parcelable != null && i < parcelable.size()) {
          fragment = (Fragment)parcelable.get(i);
        } else {
          fragment = null;
        } 
        if (paramParcelable != null && i < paramParcelable.size()) {
          viewModelStore = (ViewModelStore)paramParcelable.get(i);
        } else {
          viewModelStore = null;
        } 
        Fragment fragment = fragmentState.instantiate(this.mHost, this.mContainer, this.mParent, (FragmentManagerNonConfig)fragment, viewModelStore);
        if (DEBUG) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("restoreAllState: active #");
          stringBuilder.append(i);
          stringBuilder.append(": ");
          stringBuilder.append(fragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        this.mActive.put(fragment.mIndex, fragment);
        fragmentState.mInstance = null;
      } 
    } 
    if (paramFragmentManagerNonConfig != null) {
      List<Fragment> list = paramFragmentManagerNonConfig.getFragments();
      if (list != null) {
        i = list.size();
      } else {
        i = 0;
      } 
      int j;
      for (j = 0; j < i; j++) {
        Fragment fragment = list.get(j);
        if (fragment.mTargetIndex >= 0) {
          fragment.mTarget = (Fragment)this.mActive.get(fragment.mTargetIndex);
          if (fragment.mTarget == null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Re-attaching retained fragment ");
            stringBuilder.append(fragment);
            stringBuilder.append(" target no longer exists: ");
            stringBuilder.append(fragment.mTargetIndex);
            Log.w("FragmentManager", stringBuilder.toString());
          } 
        } 
      } 
    } 
    this.mAdded.clear();
    if (fragmentManagerState.mAdded != null) {
      i = 0;
      while (i < fragmentManagerState.mAdded.length) {
        Fragment fragment = (Fragment)this.mActive.get(fragmentManagerState.mAdded[i]);
        if (fragment == null) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("No instantiated fragment for index #");
          stringBuilder.append(fragmentManagerState.mAdded[i]);
          throwException(new IllegalStateException(stringBuilder.toString()));
        } 
        fragment.mAdded = true;
        if (DEBUG) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("restoreAllState: added #");
          stringBuilder.append(i);
          stringBuilder.append(": ");
          stringBuilder.append(fragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        if (!this.mAdded.contains(fragment)) {
          synchronized (this.mAdded) {
            this.mAdded.add(fragment);
            i++;
          } 
          continue;
        } 
        throw new IllegalStateException("Already added!");
      } 
    } 
    if (fragmentManagerState.mBackStack != null) {
      this.mBackStack = new ArrayList<BackStackRecord>(fragmentManagerState.mBackStack.length);
      for (i = 0; i < fragmentManagerState.mBackStack.length; i++) {
        BackStackRecord backStackRecord = fragmentManagerState.mBackStack[i].instantiate(this);
        if (DEBUG) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("restoreAllState: back stack #");
          stringBuilder.append(i);
          stringBuilder.append(" (index ");
          stringBuilder.append(backStackRecord.mIndex);
          stringBuilder.append("): ");
          stringBuilder.append(backStackRecord);
          Log.v("FragmentManager", stringBuilder.toString());
          PrintWriter printWriter = new PrintWriter((Writer)new LogWriter("FragmentManager"));
          backStackRecord.dump("  ", printWriter, false);
          printWriter.close();
        } 
        this.mBackStack.add(backStackRecord);
        if (backStackRecord.mIndex >= 0)
          setBackStackIndex(backStackRecord.mIndex, backStackRecord); 
      } 
    } else {
      this.mBackStack = null;
    } 
    if (fragmentManagerState.mPrimaryNavActiveIndex >= 0)
      this.mPrimaryNav = (Fragment)this.mActive.get(fragmentManagerState.mPrimaryNavActiveIndex); 
    this.mNextFragmentIndex = fragmentManagerState.mNextFragmentIndex;
  }
  
  FragmentManagerNonConfig retainNonConfig() {
    setRetaining(this.mSavedNonConfig);
    return this.mSavedNonConfig;
  }
  
  Parcelable saveAllState() {
    forcePostponedTransactions();
    endAnimatingAwayFragments();
    execPendingActions();
    this.mStateSaved = true;
    BackStackState[] arrayOfBackStackState = null;
    this.mSavedNonConfig = null;
    SparseArray<Fragment> sparseArray = this.mActive;
    if (sparseArray != null) {
      StringBuilder stringBuilder;
      if (sparseArray.size() <= 0)
        return null; 
      int k = this.mActive.size();
      FragmentState[] arrayOfFragmentState = new FragmentState[k];
      boolean bool = false;
      int i = 0;
      int j = 0;
      while (i < k) {
        Fragment fragment1 = (Fragment)this.mActive.valueAt(i);
        if (fragment1 != null) {
          if (fragment1.mIndex < 0) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Failure saving state: active ");
            stringBuilder.append(fragment1);
            stringBuilder.append(" has cleared index: ");
            stringBuilder.append(fragment1.mIndex);
            throwException(new IllegalStateException(stringBuilder.toString()));
          } 
          FragmentState fragmentState = new FragmentState(fragment1);
          arrayOfFragmentState[i] = fragmentState;
          if (fragment1.mState > 0 && fragmentState.mSavedFragmentState == null) {
            fragmentState.mSavedFragmentState = saveFragmentBasicState(fragment1);
            if (fragment1.mTarget != null) {
              if (fragment1.mTarget.mIndex < 0) {
                StringBuilder stringBuilder1 = new StringBuilder();
                stringBuilder1.append("Failure saving state: ");
                stringBuilder1.append(fragment1);
                stringBuilder1.append(" has target not in fragment manager: ");
                stringBuilder1.append(fragment1.mTarget);
                throwException(new IllegalStateException(stringBuilder1.toString()));
              } 
              if (fragmentState.mSavedFragmentState == null)
                fragmentState.mSavedFragmentState = new Bundle(); 
              putFragment(fragmentState.mSavedFragmentState, "android:target_state", fragment1.mTarget);
              if (fragment1.mTargetRequestCode != 0)
                fragmentState.mSavedFragmentState.putInt("android:target_req_state", fragment1.mTargetRequestCode); 
            } 
          } else {
            fragmentState.mSavedFragmentState = fragment1.mSavedFragmentState;
          } 
          if (DEBUG) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Saved state of ");
            stringBuilder1.append(fragment1);
            stringBuilder1.append(": ");
            stringBuilder1.append(fragmentState.mSavedFragmentState);
            Log.v("FragmentManager", stringBuilder1.toString());
          } 
          j = 1;
        } 
        i++;
      } 
      if (!j) {
        if (DEBUG)
          Log.v("FragmentManager", "saveAllState: no fragments!"); 
        return null;
      } 
      j = this.mAdded.size();
      if (j > 0) {
        int[] arrayOfInt = new int[j];
        i = 0;
        while (true) {
          int[] arrayOfInt1 = arrayOfInt;
          if (i < j) {
            arrayOfInt[i] = ((Fragment)this.mAdded.get(i)).mIndex;
            if (arrayOfInt[i] < 0) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("Failure saving state: active ");
              stringBuilder1.append(this.mAdded.get(i));
              stringBuilder1.append(" has cleared index: ");
              stringBuilder1.append(arrayOfInt[i]);
              throwException(new IllegalStateException(stringBuilder1.toString()));
            } 
            if (DEBUG) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("saveAllState: adding fragment #");
              stringBuilder1.append(i);
              stringBuilder1.append(": ");
              stringBuilder1.append(this.mAdded.get(i));
              Log.v("FragmentManager", stringBuilder1.toString());
            } 
            i++;
            continue;
          } 
          break;
        } 
      } else {
        sparseArray = null;
      } 
      ArrayList<BackStackRecord> arrayList = this.mBackStack;
      BackStackState[] arrayOfBackStackState1 = arrayOfBackStackState;
      if (arrayList != null) {
        j = arrayList.size();
        arrayOfBackStackState1 = arrayOfBackStackState;
        if (j > 0) {
          arrayOfBackStackState = new BackStackState[j];
          i = bool;
          while (true) {
            arrayOfBackStackState1 = arrayOfBackStackState;
            if (i < j) {
              arrayOfBackStackState[i] = new BackStackState(this.mBackStack.get(i));
              if (DEBUG) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("saveAllState: adding back stack #");
                stringBuilder.append(i);
                stringBuilder.append(": ");
                stringBuilder.append(this.mBackStack.get(i));
                Log.v("FragmentManager", stringBuilder.toString());
              } 
              i++;
              continue;
            } 
            break;
          } 
        } 
      } 
      FragmentManagerState fragmentManagerState = new FragmentManagerState();
      fragmentManagerState.mActive = arrayOfFragmentState;
      fragmentManagerState.mAdded = (int[])sparseArray;
      fragmentManagerState.mBackStack = (BackStackState[])stringBuilder;
      Fragment fragment = this.mPrimaryNav;
      if (fragment != null)
        fragmentManagerState.mPrimaryNavActiveIndex = fragment.mIndex; 
      fragmentManagerState.mNextFragmentIndex = this.mNextFragmentIndex;
      saveNonConfig();
      return fragmentManagerState;
    } 
    return null;
  }
  
  Bundle saveFragmentBasicState(Fragment paramFragment) {
    if (this.mStateBundle == null)
      this.mStateBundle = new Bundle(); 
    paramFragment.performSaveInstanceState(this.mStateBundle);
    dispatchOnFragmentSaveInstanceState(paramFragment, this.mStateBundle, false);
    boolean bool = this.mStateBundle.isEmpty();
    Bundle bundle2 = null;
    if (!bool) {
      bundle2 = this.mStateBundle;
      this.mStateBundle = null;
    } 
    if (paramFragment.mView != null)
      saveFragmentViewState(paramFragment); 
    Bundle bundle1 = bundle2;
    if (paramFragment.mSavedViewState != null) {
      bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle1.putSparseParcelableArray("android:view_state", paramFragment.mSavedViewState);
    } 
    bundle2 = bundle1;
    if (!paramFragment.mUserVisibleHint) {
      bundle2 = bundle1;
      if (bundle1 == null)
        bundle2 = new Bundle(); 
      bundle2.putBoolean("android:user_visible_hint", paramFragment.mUserVisibleHint);
    } 
    return bundle2;
  }
  
  public Fragment.SavedState saveFragmentInstanceState(Fragment paramFragment) {
    if (paramFragment.mIndex < 0) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" is not currently in the FragmentManager");
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    int i = paramFragment.mState;
    Fragment.SavedState savedState2 = null;
    Fragment.SavedState savedState1 = savedState2;
    if (i > 0) {
      Bundle bundle = saveFragmentBasicState(paramFragment);
      savedState1 = savedState2;
      if (bundle != null)
        savedState1 = new Fragment.SavedState(bundle); 
    } 
    return savedState1;
  }
  
  void saveFragmentViewState(Fragment paramFragment) {
    if (paramFragment.mInnerView == null)
      return; 
    SparseArray<Parcelable> sparseArray = this.mStateArray;
    if (sparseArray == null) {
      this.mStateArray = new SparseArray();
    } else {
      sparseArray.clear();
    } 
    paramFragment.mInnerView.saveHierarchyState(this.mStateArray);
    if (this.mStateArray.size() > 0) {
      paramFragment.mSavedViewState = this.mStateArray;
      this.mStateArray = null;
    } 
  }
  
  void saveNonConfig() {
    List<FragmentManagerNonConfig> list1;
    List<FragmentManagerNonConfig> list2;
    List<FragmentManagerNonConfig> list3;
    if (this.mActive != null) {
      ArrayList<Fragment> arrayList1 = null;
      ArrayList<Fragment> arrayList3 = arrayList1;
      ArrayList<Fragment> arrayList2 = arrayList3;
      int i = 0;
      while (true) {
        list3 = (List)arrayList1;
        list2 = (List)arrayList3;
        list1 = (List)arrayList2;
        if (i < this.mActive.size()) {
          ArrayList<Fragment> arrayList4;
          Fragment fragment = (Fragment)this.mActive.valueAt(i);
          list2 = (List)arrayList1;
          list3 = (List)arrayList3;
          ArrayList<Fragment> arrayList5 = arrayList2;
          if (fragment != null) {
            FragmentManagerNonConfig fragmentManagerNonConfig;
            list1 = (List)arrayList1;
            if (fragment.mRetainInstance) {
              byte b;
              list2 = (List)arrayList1;
              if (arrayList1 == null)
                list2 = new ArrayList(); 
              list2.add(fragment);
              if (fragment.mTarget != null) {
                b = fragment.mTarget.mIndex;
              } else {
                b = -1;
              } 
              fragment.mTargetIndex = b;
              list1 = list2;
              if (DEBUG) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("retainNonConfig: keeping retained ");
                stringBuilder.append(fragment);
                Log.v("FragmentManager", stringBuilder.toString());
                list1 = list2;
              } 
            } 
            if (fragment.mChildFragmentManager != null) {
              fragment.mChildFragmentManager.saveNonConfig();
              fragmentManagerNonConfig = fragment.mChildFragmentManager.mSavedNonConfig;
            } else {
              fragmentManagerNonConfig = fragment.mChildNonConfig;
            } 
            arrayList1 = arrayList3;
            if (arrayList3 == null) {
              arrayList1 = arrayList3;
              if (fragmentManagerNonConfig != null) {
                arrayList3 = new ArrayList<Fragment>(this.mActive.size());
                int j = 0;
                while (true) {
                  arrayList1 = arrayList3;
                  if (j < i) {
                    arrayList3.add(null);
                    j++;
                    continue;
                  } 
                  break;
                } 
              } 
            } 
            if (arrayList1 != null)
              arrayList1.add(fragmentManagerNonConfig); 
            arrayList3 = arrayList2;
            if (arrayList2 == null) {
              arrayList3 = arrayList2;
              if (fragment.mViewModelStore != null) {
                arrayList2 = new ArrayList<Fragment>(this.mActive.size());
                int j = 0;
                while (true) {
                  arrayList3 = arrayList2;
                  if (j < i) {
                    arrayList2.add(null);
                    j++;
                    continue;
                  } 
                  break;
                } 
              } 
            } 
            arrayList4 = (ArrayList)list1;
            list3 = (List)arrayList1;
            arrayList5 = arrayList3;
            if (arrayList3 != null) {
              arrayList3.add(fragment.mViewModelStore);
              arrayList5 = arrayList3;
              list3 = (List)arrayList1;
              arrayList4 = (ArrayList)list1;
            } 
          } 
          i++;
          arrayList1 = arrayList4;
          arrayList3 = (ArrayList)list3;
          arrayList2 = arrayList5;
          continue;
        } 
        break;
      } 
    } else {
      list3 = null;
      List<FragmentManagerNonConfig> list = list3;
      list1 = list;
      list2 = list;
    } 
    if (list3 == null && list2 == null && list1 == null) {
      this.mSavedNonConfig = null;
      return;
    } 
    this.mSavedNonConfig = new FragmentManagerNonConfig((List)list3, list2, (List)list1);
  }
  
  void scheduleCommit() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   6: astore #4
    //   8: iconst_0
    //   9: istore_3
    //   10: aload #4
    //   12: ifnull -> 96
    //   15: aload_0
    //   16: getfield mPostponedTransactions : Ljava/util/ArrayList;
    //   19: invokevirtual isEmpty : ()Z
    //   22: ifne -> 96
    //   25: iconst_1
    //   26: istore_1
    //   27: goto -> 30
    //   30: iload_3
    //   31: istore_2
    //   32: aload_0
    //   33: getfield mPendingActions : Ljava/util/ArrayList;
    //   36: ifnull -> 101
    //   39: iload_3
    //   40: istore_2
    //   41: aload_0
    //   42: getfield mPendingActions : Ljava/util/ArrayList;
    //   45: invokevirtual size : ()I
    //   48: iconst_1
    //   49: if_icmpne -> 101
    //   52: iconst_1
    //   53: istore_2
    //   54: goto -> 101
    //   57: aload_0
    //   58: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   61: invokevirtual getHandler : ()Landroid/os/Handler;
    //   64: aload_0
    //   65: getfield mExecCommit : Ljava/lang/Runnable;
    //   68: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   71: aload_0
    //   72: getfield mHost : Landroidx/fragment/app/FragmentHostCallback;
    //   75: invokevirtual getHandler : ()Landroid/os/Handler;
    //   78: aload_0
    //   79: getfield mExecCommit : Ljava/lang/Runnable;
    //   82: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   85: pop
    //   86: aload_0
    //   87: monitorexit
    //   88: return
    //   89: astore #4
    //   91: aload_0
    //   92: monitorexit
    //   93: aload #4
    //   95: athrow
    //   96: iconst_0
    //   97: istore_1
    //   98: goto -> 30
    //   101: iload_1
    //   102: ifne -> 57
    //   105: iload_2
    //   106: ifeq -> 86
    //   109: goto -> 57
    // Exception table:
    //   from	to	target	type
    //   2	8	89	finally
    //   15	25	89	finally
    //   32	39	89	finally
    //   41	52	89	finally
    //   57	86	89	finally
    //   86	88	89	finally
    //   91	93	89	finally
  }
  
  public void setBackStackIndex(int paramInt, BackStackRecord paramBackStackRecord) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   6: ifnonnull -> 20
    //   9: aload_0
    //   10: new java/util/ArrayList
    //   13: dup
    //   14: invokespecial <init> : ()V
    //   17: putfield mBackStackIndices : Ljava/util/ArrayList;
    //   20: aload_0
    //   21: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   24: invokevirtual size : ()I
    //   27: istore #4
    //   29: iload #4
    //   31: istore_3
    //   32: iload_1
    //   33: iload #4
    //   35: if_icmpge -> 109
    //   38: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   41: ifeq -> 96
    //   44: new java/lang/StringBuilder
    //   47: dup
    //   48: invokespecial <init> : ()V
    //   51: astore #5
    //   53: aload #5
    //   55: ldc_w 'Setting back stack index '
    //   58: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   61: pop
    //   62: aload #5
    //   64: iload_1
    //   65: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   68: pop
    //   69: aload #5
    //   71: ldc_w ' to '
    //   74: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   77: pop
    //   78: aload #5
    //   80: aload_2
    //   81: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   84: pop
    //   85: ldc 'FragmentManager'
    //   87: aload #5
    //   89: invokevirtual toString : ()Ljava/lang/String;
    //   92: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   95: pop
    //   96: aload_0
    //   97: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   100: iload_1
    //   101: aload_2
    //   102: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   105: pop
    //   106: goto -> 269
    //   109: iload_3
    //   110: iload_1
    //   111: if_icmpge -> 202
    //   114: aload_0
    //   115: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   118: aconst_null
    //   119: invokevirtual add : (Ljava/lang/Object;)Z
    //   122: pop
    //   123: aload_0
    //   124: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   127: ifnonnull -> 141
    //   130: aload_0
    //   131: new java/util/ArrayList
    //   134: dup
    //   135: invokespecial <init> : ()V
    //   138: putfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   141: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   144: ifeq -> 183
    //   147: new java/lang/StringBuilder
    //   150: dup
    //   151: invokespecial <init> : ()V
    //   154: astore #5
    //   156: aload #5
    //   158: ldc_w 'Adding available back stack index '
    //   161: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   164: pop
    //   165: aload #5
    //   167: iload_3
    //   168: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   171: pop
    //   172: ldc 'FragmentManager'
    //   174: aload #5
    //   176: invokevirtual toString : ()Ljava/lang/String;
    //   179: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   182: pop
    //   183: aload_0
    //   184: getfield mAvailBackStackIndices : Ljava/util/ArrayList;
    //   187: iload_3
    //   188: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   191: invokevirtual add : (Ljava/lang/Object;)Z
    //   194: pop
    //   195: iload_3
    //   196: iconst_1
    //   197: iadd
    //   198: istore_3
    //   199: goto -> 109
    //   202: getstatic androidx/fragment/app/FragmentManagerImpl.DEBUG : Z
    //   205: ifeq -> 260
    //   208: new java/lang/StringBuilder
    //   211: dup
    //   212: invokespecial <init> : ()V
    //   215: astore #5
    //   217: aload #5
    //   219: ldc_w 'Adding back stack index '
    //   222: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   225: pop
    //   226: aload #5
    //   228: iload_1
    //   229: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   232: pop
    //   233: aload #5
    //   235: ldc_w ' with '
    //   238: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   241: pop
    //   242: aload #5
    //   244: aload_2
    //   245: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   248: pop
    //   249: ldc 'FragmentManager'
    //   251: aload #5
    //   253: invokevirtual toString : ()Ljava/lang/String;
    //   256: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   259: pop
    //   260: aload_0
    //   261: getfield mBackStackIndices : Ljava/util/ArrayList;
    //   264: aload_2
    //   265: invokevirtual add : (Ljava/lang/Object;)Z
    //   268: pop
    //   269: aload_0
    //   270: monitorexit
    //   271: return
    //   272: astore_2
    //   273: aload_0
    //   274: monitorexit
    //   275: goto -> 280
    //   278: aload_2
    //   279: athrow
    //   280: goto -> 278
    // Exception table:
    //   from	to	target	type
    //   2	20	272	finally
    //   20	29	272	finally
    //   38	96	272	finally
    //   96	106	272	finally
    //   114	141	272	finally
    //   141	183	272	finally
    //   183	195	272	finally
    //   202	260	272	finally
    //   260	269	272	finally
    //   269	271	272	finally
    //   273	275	272	finally
  }
  
  public void setPrimaryNavigationFragment(Fragment paramFragment) {
    if (paramFragment == null || (this.mActive.get(paramFragment.mIndex) == paramFragment && (paramFragment.mHost == null || paramFragment.getFragmentManager() == this))) {
      this.mPrimaryNav = paramFragment;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void showFragment(Fragment paramFragment) {
    if (DEBUG) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("show: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mHidden) {
      paramFragment.mHidden = false;
      paramFragment.mHiddenChanged ^= 0x1;
    } 
  }
  
  void startPendingDeferredFragments() {
    if (this.mActive == null)
      return; 
    for (int i = 0; i < this.mActive.size(); i++) {
      Fragment fragment = (Fragment)this.mActive.valueAt(i);
      if (fragment != null)
        performPendingDeferredStart(fragment); 
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("FragmentManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    Fragment fragment = this.mParent;
    if (fragment != null) {
      DebugUtils.buildShortClassTag(fragment, stringBuilder);
    } else {
      DebugUtils.buildShortClassTag(this.mHost, stringBuilder);
    } 
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  public void unregisterFragmentLifecycleCallbacks(FragmentManager.FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   4: astore #4
    //   6: aload #4
    //   8: monitorenter
    //   9: iconst_0
    //   10: istore_2
    //   11: aload_0
    //   12: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   15: invokevirtual size : ()I
    //   18: istore_3
    //   19: iload_2
    //   20: iload_3
    //   21: if_icmpge -> 54
    //   24: aload_0
    //   25: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   28: iload_2
    //   29: invokevirtual get : (I)Ljava/lang/Object;
    //   32: checkcast androidx/fragment/app/FragmentManagerImpl$FragmentLifecycleCallbacksHolder
    //   35: getfield mCallback : Landroidx/fragment/app/FragmentManager$FragmentLifecycleCallbacks;
    //   38: aload_1
    //   39: if_acmpne -> 70
    //   42: aload_0
    //   43: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   46: iload_2
    //   47: invokevirtual remove : (I)Ljava/lang/Object;
    //   50: pop
    //   51: goto -> 54
    //   54: aload #4
    //   56: monitorexit
    //   57: return
    //   58: astore_1
    //   59: aload #4
    //   61: monitorexit
    //   62: goto -> 67
    //   65: aload_1
    //   66: athrow
    //   67: goto -> 65
    //   70: iload_2
    //   71: iconst_1
    //   72: iadd
    //   73: istore_2
    //   74: goto -> 19
    // Exception table:
    //   from	to	target	type
    //   11	19	58	finally
    //   24	51	58	finally
    //   54	57	58	finally
    //   59	62	58	finally
  }
  
  private static class AnimateOnHWLayerIfNeededListener extends AnimationListenerWrapper {
    View mView;
    
    AnimateOnHWLayerIfNeededListener(View param1View, Animation.AnimationListener param1AnimationListener) {
      super(param1AnimationListener);
      this.mView = param1View;
    }
    
    public void onAnimationEnd(Animation param1Animation) {
      if (ViewCompat.isAttachedToWindow(this.mView) || Build.VERSION.SDK_INT >= 24) {
        this.mView.post(new Runnable() {
              public void run() {
                FragmentManagerImpl.AnimateOnHWLayerIfNeededListener.this.mView.setLayerType(0, null);
              }
            });
      } else {
        this.mView.setLayerType(0, null);
      } 
      super.onAnimationEnd(param1Animation);
    }
  }
  
  class null implements Runnable {
    public void run() {
      this.this$0.mView.setLayerType(0, null);
    }
  }
  
  private static class AnimationListenerWrapper implements Animation.AnimationListener {
    private final Animation.AnimationListener mWrapped;
    
    AnimationListenerWrapper(Animation.AnimationListener param1AnimationListener) {
      this.mWrapped = param1AnimationListener;
    }
    
    public void onAnimationEnd(Animation param1Animation) {
      Animation.AnimationListener animationListener = this.mWrapped;
      if (animationListener != null)
        animationListener.onAnimationEnd(param1Animation); 
    }
    
    public void onAnimationRepeat(Animation param1Animation) {
      Animation.AnimationListener animationListener = this.mWrapped;
      if (animationListener != null)
        animationListener.onAnimationRepeat(param1Animation); 
    }
    
    public void onAnimationStart(Animation param1Animation) {
      Animation.AnimationListener animationListener = this.mWrapped;
      if (animationListener != null)
        animationListener.onAnimationStart(param1Animation); 
    }
  }
  
  private static class AnimationOrAnimator {
    public final Animation animation = null;
    
    public final Animator animator;
    
    AnimationOrAnimator(Animator param1Animator) {
      this.animator = param1Animator;
      if (param1Animator != null)
        return; 
      throw new IllegalStateException("Animator cannot be null");
    }
    
    AnimationOrAnimator(Animation param1Animation) {
      this.animator = null;
      if (param1Animation != null)
        return; 
      throw new IllegalStateException("Animation cannot be null");
    }
  }
  
  private static class AnimatorOnHWLayerIfNeededListener extends AnimatorListenerAdapter {
    View mView;
    
    AnimatorOnHWLayerIfNeededListener(View param1View) {
      this.mView = param1View;
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      this.mView.setLayerType(0, null);
      param1Animator.removeListener((Animator.AnimatorListener)this);
    }
    
    public void onAnimationStart(Animator param1Animator) {
      this.mView.setLayerType(2, null);
    }
  }
  
  private static class EndViewTransitionAnimator extends AnimationSet implements Runnable {
    private boolean mAnimating = true;
    
    private final View mChild;
    
    private boolean mEnded;
    
    private final ViewGroup mParent;
    
    private boolean mTransitionEnded;
    
    EndViewTransitionAnimator(Animation param1Animation, ViewGroup param1ViewGroup, View param1View) {
      super(false);
      this.mParent = param1ViewGroup;
      this.mChild = param1View;
      addAnimation(param1Animation);
      this.mParent.post(this);
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation) {
      this.mAnimating = true;
      if (this.mEnded)
        return this.mTransitionEnded ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation)) {
        this.mEnded = true;
        OneShotPreDrawListener.add((View)this.mParent, this);
      } 
      return true;
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation, float param1Float) {
      this.mAnimating = true;
      if (this.mEnded)
        return this.mTransitionEnded ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation, param1Float)) {
        this.mEnded = true;
        OneShotPreDrawListener.add((View)this.mParent, this);
      } 
      return true;
    }
    
    public void run() {
      if (!this.mEnded && this.mAnimating) {
        this.mAnimating = false;
        this.mParent.post(this);
        return;
      } 
      this.mParent.endViewTransition(this.mChild);
      this.mTransitionEnded = true;
    }
  }
  
  private static final class FragmentLifecycleCallbacksHolder {
    final FragmentManager.FragmentLifecycleCallbacks mCallback;
    
    final boolean mRecursive;
    
    FragmentLifecycleCallbacksHolder(FragmentManager.FragmentLifecycleCallbacks param1FragmentLifecycleCallbacks, boolean param1Boolean) {
      this.mCallback = param1FragmentLifecycleCallbacks;
      this.mRecursive = param1Boolean;
    }
  }
  
  static class FragmentTag {
    public static final int[] Fragment = new int[] { 16842755, 16842960, 16842961 };
    
    public static final int Fragment_id = 1;
    
    public static final int Fragment_name = 0;
    
    public static final int Fragment_tag = 2;
  }
  
  static interface OpGenerator {
    boolean generateOps(ArrayList<BackStackRecord> param1ArrayList, ArrayList<Boolean> param1ArrayList1);
  }
  
  private class PopBackStackState implements OpGenerator {
    final int mFlags;
    
    final int mId;
    
    final String mName;
    
    PopBackStackState(String param1String, int param1Int1, int param1Int2) {
      this.mName = param1String;
      this.mId = param1Int1;
      this.mFlags = param1Int2;
    }
    
    public boolean generateOps(ArrayList<BackStackRecord> param1ArrayList, ArrayList<Boolean> param1ArrayList1) {
      if (FragmentManagerImpl.this.mPrimaryNav != null && this.mId < 0 && this.mName == null) {
        FragmentManager fragmentManager = FragmentManagerImpl.this.mPrimaryNav.peekChildFragmentManager();
        if (fragmentManager != null && fragmentManager.popBackStackImmediate())
          return false; 
      } 
      return FragmentManagerImpl.this.popBackStackState(param1ArrayList, param1ArrayList1, this.mName, this.mId, this.mFlags);
    }
  }
  
  static class StartEnterTransitionListener implements Fragment.OnStartEnterTransitionListener {
    final boolean mIsBack;
    
    private int mNumPostponed;
    
    final BackStackRecord mRecord;
    
    StartEnterTransitionListener(BackStackRecord param1BackStackRecord, boolean param1Boolean) {
      this.mIsBack = param1Boolean;
      this.mRecord = param1BackStackRecord;
    }
    
    public void cancelTransaction() {
      this.mRecord.mManager.completeExecute(this.mRecord, this.mIsBack, false, false);
    }
    
    public void completeTransaction() {
      int i = this.mNumPostponed;
      int j = 0;
      if (i > 0) {
        i = 1;
      } else {
        i = 0;
      } 
      FragmentManagerImpl fragmentManagerImpl = this.mRecord.mManager;
      int k = fragmentManagerImpl.mAdded.size();
      while (j < k) {
        Fragment fragment = fragmentManagerImpl.mAdded.get(j);
        fragment.setOnStartEnterTransitionListener(null);
        if (i != 0 && fragment.isPostponed())
          fragment.startPostponedEnterTransition(); 
        j++;
      } 
      this.mRecord.mManager.completeExecute(this.mRecord, this.mIsBack, i ^ 0x1, true);
    }
    
    public boolean isReady() {
      return (this.mNumPostponed == 0);
    }
    
    public void onStartEnterTransition() {
      int i = this.mNumPostponed - 1;
      this.mNumPostponed = i;
      if (i != 0)
        return; 
      this.mRecord.mManager.scheduleCommit();
    }
    
    public void startListening() {
      this.mNumPostponed++;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Guys Race-dex2jar.jar!\androidx\fragment\app\FragmentManagerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */