package androidx.lifecycle;

@Deprecated
public interface LifecycleRegistryOwner extends LifecycleOwner {
  LifecycleRegistry getLifecycle();
}


/* Location:              C:\soft\dex2jar-2.0\Guys Race-dex2jar.jar!\androidx\lifecycle\LifecycleRegistryOwner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */